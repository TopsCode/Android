<?php

include('connection.php');

$date=$_POST['date'];
$title=$_POST['title'];
$description=$_POST['description'];


$sql="insert into notice(date,title,description) values ('$date','$title','$description')";

if(mysqli_query($con,$sql)){
    echo json_encode(array('response'=>"successfully added"));
}
else{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>