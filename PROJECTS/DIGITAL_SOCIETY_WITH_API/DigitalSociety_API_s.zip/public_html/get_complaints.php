<?php
include('connection.php');

$sql="select * from complaints WHERE status='PENDING'";
$result=mysqli_query($con,$sql);

$response=array();

while($row=mysqli_fetch_array($result))
{
    
    array_push($response,array('id'=>$row['id'],'name'=>$row['name'],'building_name'=>$row['building_name'],'room_no'=>$row['room_no'],'subject'=>$row['subject'],'description'=>$row['description']));
    
}
echo json_encode($response);
mysqli_close($con);

?>