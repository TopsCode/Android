<?php

include('connection.php');

$id=$_POST['id'];

$sql="DELETE from complaints where id='$id' ";

if(mysqli_query($con,$sql))
{
    echo json_encode(array('response'=>"successfully deleted"));
}
else
{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>