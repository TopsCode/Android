<?php
include('connection.php');

$sql="select * from notice";
$result=mysqli_query($con,$sql);

$response=array();

while($row=mysqli_fetch_array($result))
{
    
    array_push($response,array('id'=>$row['id'],'date'=>$row['date'],'title'=>$row['title'],'description'=>$row['description']));
    
}
echo json_encode($response);
mysqli_close($con);

?>