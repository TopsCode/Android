<?php
include('connection.php');

$sql="select * from Event";
$result=mysqli_query($con,$sql);

$response=array();

while($row=mysqli_fetch_array($result))
{
    
    array_push($response,array('Date'=>$row['Date'],'Event_name'=>$row['Event_name'],'Description'=>$row['Description']));
    
}
echo json_encode($response);
mysqli_close($con);

?>