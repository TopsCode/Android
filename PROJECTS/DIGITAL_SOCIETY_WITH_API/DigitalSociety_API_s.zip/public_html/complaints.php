<?php

include('connection.php');

$name=$_POST['name'];
$building_name=$_POST['building_name'];
$room_no=$_POST['room_no'];
$subject=$_POST['subject'];
$description=$_POST['description'];


$sql="insert into complaints(name,building_name,room_no,subject,description) values 
('$name','$building_name','$room_no','$subject','$description')";

if(mysqli_query($con,$sql)){
    echo json_encode(array('response'=>"successfully added"));
}
else{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>