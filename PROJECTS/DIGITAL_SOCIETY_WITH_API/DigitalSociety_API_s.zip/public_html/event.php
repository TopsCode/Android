<?php

include('connection.php');

$Date=$_POST['Date'];
$Event_name=$_POST['Event_name'];
$Description=$_POST['Description'];


$sql="insert into Event(Date,Event_name,Description) values ('$Date','$Event_name','$Description')";

if(mysqli_query($con,$sql)){
    echo json_encode(array('response'=>"successfully added"));
}
else{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>