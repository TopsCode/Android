<?php

$host="localhost";
$user="id15529975_root";
$pw="android@456Tops";
$db="id15529975_mydb";

$con=mysqli_connect("localhost","id15529975_root","android@456Tops","id15529975_mydb") or die("disconnect");

?>