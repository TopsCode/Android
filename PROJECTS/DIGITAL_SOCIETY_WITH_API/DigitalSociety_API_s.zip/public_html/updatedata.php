<?php

include('connection.php');

$id=$_POST['id'];
$Name=$_POST['Name'];
$Email=$_POST['Email'];
$Phone=$_POST['Phone'];
$Buildingname=$_POST['Buildingname'];
$Room=$_POST['Room'];
$Occupation=$_POST['Occupation'];


$sql="UPDATE `members` SET Name='$Name',Email='$Email',Phone='$Phone',Buildingname='$Buildingname',Room='$Room',Occupation='$Occupation' WHERE id='$id' ";

if(mysqli_query($con,$sql))
{
    echo json_encode(array('response'=>"successfully update"));
}
else
{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>