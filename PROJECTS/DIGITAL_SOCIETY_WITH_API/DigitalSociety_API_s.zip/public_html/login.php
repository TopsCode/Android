<?php
include('connection.php');

$Name=$_GET['Name'];
$Phone=$_GET['Phone'];

$sql="select * from members where Name='$Name' and Phone='$Phone' ";

$result=mysqli_query($con,$sql);

$response=array();

while($row=mysqli_fetch_array($result))
{
array_push($response,array('id'=>$row['id'],'Name'=>$row['Name'],'Phone'=>$row['Phone']));
}

echo json_encode($response);

mysqli_close($con);

?>