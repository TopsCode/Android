<?php

include('connection.php');

$id=$_POST['id'];


$sql="UPDATE `complaints` SET status='APPROVE' WHERE id='$id' ";

if(mysqli_query($con,$sql))
{
    echo json_encode(array('response'=>"successfully update"));
}
else
{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>