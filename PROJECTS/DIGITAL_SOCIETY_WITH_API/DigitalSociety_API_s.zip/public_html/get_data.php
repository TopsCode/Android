<?php
include('connection.php');

$sql="select * from members";
$result=mysqli_query($con,$sql);

$response=array();

while($row=mysqli_fetch_array($result))
{
    
    array_push($response,array('Name'=>$row['Name'],'Email'=>$row['Email'],'Phone'=>$row['Phone'],'Buildingname'=>$row['Buildingname'],'Room'=>$row['Room'],'Occupation'=>$row['Occupation']));
    
}
echo json_encode($response);
mysqli_close($con);

?>