<?php

include('connection.php');

$Name=$_POST['Name'];
$Email=$_POST['Email'];
$Phone=$_POST['Phone'];
$Buildingname=$_POST['Buildingname'];
$Room=$_POST['Room'];
$Occupation=$_POST['Occupation'];

$sql="insert into members(Name,Email,Phone,Buildingname,Room,Occupation) values ('$Name','$Email','$Phone','$Buildingname','$Room','$Occupation')";

if(mysqli_query($con,$sql)){
    echo json_encode(array('response'=>"successfully added"));
}
else{
    echo json_encode(array('response'=>"Failed"));
}
mysqli_close($con);
?>