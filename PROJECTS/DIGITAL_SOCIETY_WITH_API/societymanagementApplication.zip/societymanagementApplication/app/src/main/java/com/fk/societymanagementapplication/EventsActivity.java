package com.fk.societymanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EventsActivity extends AppCompatActivity {
EditText edate,ename,edesc;
Button ebtn;

ApiInterface apiInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        edate=findViewById(R.id.edate);
        ename=findViewById(R.id.ename);
        edesc=findViewById(R.id.edesc);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        ebtn=findViewById(R.id.ebtn);

        ebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Call<myevents> call=apiInterface.postevent(edate.getText().toString(),ename.getText().toString(),edesc.getText().toString());
                String Date=edate.getText().toString();
                String EName=ename.getText().toString();
                String Desc=edesc.getText().toString();

                if (TextUtils.isEmpty(Date)){
                    edate.setError("please fill the date");
                }if (TextUtils.isEmpty(EName)){
                    ename.setError("please mention the event");
                }if (TextUtils.isEmpty(Desc)){
                    edesc.setError("please fill the description");
                }else {
                    call.enqueue(new Callback<myevents>() {
                        @Override
                        public void onResponse(Call<myevents> call, Response<myevents> response) {
                            myevents my = response.body();
                            Toast.makeText(EventsActivity.this, "" + my.getResponse(), Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(Call<myevents> call, Throwable t) {

                        }

                    });

                }
            }
        });

    }
}