package com.fk.societymanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
EditText etuser,etpass;
TextView tvnew,tvadmin;
Button btnlogin;
Myshared mysp;
ApiInterface apiInterface;
List<mymembers> mymembersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(Build.VERSION.SDK_INT>=21){
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        setContentView(R.layout.activity_main);
        setTitle("Login");

        mysp=new Myshared(MainActivity.this);
        boolean status;
        status=mysp.checkstatus();

        if(status)
        {
            Intent i=new Intent(MainActivity.this,DashBoardActivity.class);
            startActivity(i);
        }

        etuser=findViewById(R.id.etuser);
        etpass=findViewById(R.id.etpass);
        tvnew=findViewById(R.id.tvnew);
        tvadmin=findViewById(R.id.tvadmin);
        btnlogin=findViewById(R.id.btnlogin);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        changeStatusBarColor();

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String user = etuser.getText().toString();
                String pass = etpass.getText().toString();
                if (TextUtils.isEmpty(user)) {
                    etuser.setError("enter username");
                }
                if (TextUtils.isEmpty(pass)) {
                    etpass.setError("enter pass");
                } else {

                    Call<List<mymembers>> call = apiInterface.getspecificuser(etuser.getText().toString(), etpass.getText().toString());
                    
                        call.enqueue(new Callback<List<mymembers>>() {
                            @Override

                            public void onResponse(Call<List<mymembers>> call, Response<List<mymembers>> response) {
                                mymembersList = response.body();


                                if (!mymembersList.isEmpty())
                                {
                                    Toast.makeText(MainActivity.this, "IS Empty", Toast.LENGTH_SHORT).show();

                                    String id=mymembersList.get(0).getId();

                                    //Toast.makeText(MainActivity.this, "id .............."+mymembersList.get(0).getId(), Toast.LENGTH_SHORT).show();
                                    mysp.addData(id);  // store id in shared preference
                                    mysp.loginStatus(true);

                                    Log.d("mydata","id : "+id);

                                    Intent i = new Intent(MainActivity.this, DashBoardActivity.class);
                                    etuser.setText("");
                                    etpass.setText("");
                                    finish();
                                    startActivity(i);

//                                    Log.d("mydata","username : "+mymembersList.get(0).getName());

                               //     Toast.makeText(MainActivity.this, "username-----------------"+mymembersList.get(0).getName(), Toast.LENGTH_SHORT).show();

                                }
                                else
                                {
                                    Toast.makeText(MainActivity.this, "Invalid email or password ", Toast.LENGTH_SHORT).show();
                                }

                            }

                            @Override
                            public void onFailure(Call<List<mymembers>> call, Throwable t) {

                            }
                        });


                }
            }
        });


        tvnew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,NewRegActivity.class);
                startActivity(intent);
            }
        });
        tvadmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,AdminActivity.class);
                startActivity(intent);
            }
        });
    }
    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }
    }

}