package com.fk.societymanagementapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.HashMap;
import java.util.List;

public class DashBoardActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    AppBarConfiguration appBarConfiguration;
    NavigationView navv;
    Toolbar mytoolbar;
    DrawerLayout mydrawer;


    Myshared mysp;
    HashMap hm=new HashMap();

    String result;
    ApiInterface apiInterface;
    List<mymembers> mymembersList;
    TextView username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        setTitle("DashBoard");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        navv=findViewById(R.id.navv);
        mydrawer=findViewById(R.id.mydrawer);

//        username=mydrawer.findViewById(R.id.username);  //drawer username

        NavigationView navigationView = (NavigationView) findViewById(R.id.navv);
        View headerView = navigationView.getHeaderView(0);
        final TextView navUsername = (TextView) headerView.findViewById(R.id.username);

        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.navv);


        mysp=new Myshared(this);
        hm=mysp.getData();
        result= (String) hm.get(Myshared.KEYDATA);

        Log.d("mydata","result id "+result);
        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        Call<List<mymembers>> call=apiInterface.getuser(result);
        call.enqueue(new Callback<List<mymembers>>() {
            @Override
            public void onResponse(Call<List<mymembers>> call, Response<List<mymembers>> response) {
                mymembersList=response.body();
                Toast.makeText(DashBoardActivity.this, ""+mymembersList, Toast.LENGTH_SHORT).show();
                navUsername.setText(mymembersList.get(0).getName());
                Log.d("mydata","username"+mymembersList.get(0).getName());
            }

            @Override
            public void onFailure(Call<List<mymembers>> call, Throwable t) {
                Toast.makeText(DashBoardActivity.this, ""+t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d("mydata","FAIL");
            }
        });

//        String id=getIntent().getStringExtra("keyid");

        appBarConfiguration=new AppBarConfiguration.Builder(R.id.username,R.id.profileFragment,R.id.aboutFragment,R.id.contactFragment,R.id.complaintsFragment,R.id.membersFragment,R.id.noticeFragment,R.id.eventsFragment)
                .setDrawerLayout(mydrawer)
                .build();

        NavController navController= Navigation.findNavController(DashBoardActivity.this,R.id.fragment);
        NavigationUI.setupActionBarWithNavController(DashBoardActivity.this,navController,appBarConfiguration);
        NavigationUI.setupWithNavController(navv,navController);

    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController= Navigation.findNavController(DashBoardActivity.this,R.id.fragment);
        return NavigationUI.navigateUp(navController,appBarConfiguration) ||
                super.onSupportNavigateUp();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_logout,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.logout){
            mysp.clearData();
            Intent i=new Intent(DashBoardActivity.this,MainActivity.class);
            finish();
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }
}
