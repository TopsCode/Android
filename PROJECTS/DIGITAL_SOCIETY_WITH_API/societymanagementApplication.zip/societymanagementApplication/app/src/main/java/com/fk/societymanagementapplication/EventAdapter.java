package com.fk.societymanagementapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.Myclass> {
    Context context;
    List<myevents> myeventsList;

    public EventAdapter(Context context, List<myevents> myeventsList) {
        this.context = context;
        this.myeventsList = myeventsList;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.eventlayout,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
    myevents my=myeventsList.get(position);
    holder.etdate.setText(my.getDate());
    holder.etname.setText(my.getEvent_name());
    holder.etdesc.setText(my.getDescription());
    }

    @Override
    public int getItemCount() {
        return myeventsList.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        TextView etdate,etname,etdesc;
        public Myclass(@NonNull View itemView) {
            super(itemView);
        etdate=itemView.findViewById(R.id.etdate);
        etname=itemView.findViewById(R.id.etname);
        etdesc=itemView.findViewById(R.id.etdesc);
        }
    }
}
