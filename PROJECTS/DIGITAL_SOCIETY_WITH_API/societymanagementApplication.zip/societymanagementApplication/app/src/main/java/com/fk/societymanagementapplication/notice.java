package com.fk.societymanagementapplication;

import com.google.gson.annotations.SerializedName;

public class notice {
    @SerializedName("id")
    String id;
    @SerializedName("date")
    String date;
    @SerializedName("title")
    String title;
    @SerializedName("description")
    String desc;

    public String Response;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getResponse() {
        return Response;
    }

    public notice(String id,String date, String title, String desc) {
        this.id = id;
        this.date = date;
        this.title = title;
        this.desc = desc;
    }
}
