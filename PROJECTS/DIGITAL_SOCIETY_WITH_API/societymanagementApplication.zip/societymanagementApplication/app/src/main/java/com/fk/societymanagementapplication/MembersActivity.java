package com.fk.societymanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MembersActivity extends AppCompatActivity {

RecyclerView recv;
ApiInterface apiInterface;
List<mymembers> mymembersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_members);
        recv=findViewById(R.id.recv);

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE,Manifest.permission.WRITE_CONTACTS},1);


        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(MembersActivity.this);
        recv.setLayoutManager(layoutManager);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        Call<List<mymembers>> call=apiInterface.getmembers();

        call.enqueue(new Callback<List<mymembers>>() {
            @Override
            public void onResponse(Call<List<mymembers>> call, Response<List<mymembers>> response) {
            mymembersList=response.body();
            membersAdapter adapter=new membersAdapter(MembersActivity.this,mymembersList);
            recv.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<mymembers>> call, Throwable t) {

            }
        });
    }
}