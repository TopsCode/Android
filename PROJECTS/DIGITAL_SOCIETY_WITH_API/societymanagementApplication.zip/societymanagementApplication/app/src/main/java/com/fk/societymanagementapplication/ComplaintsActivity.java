package com.fk.societymanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.os.Bundle;

import java.util.List;

public class ComplaintsActivity extends AppCompatActivity {
RecyclerView recv;
ApiInterface apiInterface;
List<complaints> complaintsList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(ComplaintsActivity.this);
        recv.setLayoutManager(layoutManager);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);
        Call<List<complaints>> call=apiInterface.getcomplaints();

        call.enqueue(new Callback<List<complaints>>() {
            @Override
            public void onResponse(Call<List<complaints>> call, Response<List<complaints>> response) {
                complaintsList=response.body();
                complaintsAdapter adapter=new complaintsAdapter(ComplaintsActivity.this,complaintsList);
                recv.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<complaints>> call, Throwable t) {

            }
        });
    }
}