package com.fk.societymanagementapplication;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class Myshared {

    public static final String KEYDATA = "DATA";
    Context context;
    SharedPreferences sp;
    SharedPreferences.Editor editor;

    public Myshared(Context context) {
        this.context = context;
        sp = context.getSharedPreferences("MYPREF", Context.MODE_PRIVATE);
    }

    public void loginStatus(boolean status){
        editor=sp.edit();
        editor.putBoolean("status",status);
        editor.commit();
    }

    public boolean checkstatus()
    {
        boolean status=false;
        status=sp.getBoolean("status",false);
        return status;
    }


    public void addData(String id){
        editor=sp.edit();
        editor.putString(KEYDATA,id);
        editor.commit();
    }
    public HashMap<String,String> getData()
    {
        HashMap hm=new HashMap();
        hm.put(KEYDATA,sp.getString(KEYDATA,"DEFAULT"));
        return hm;
    }
    public void clearData()
    {
        editor=sp.edit();
        editor.clear();
        editor.commit();
    }
}


