package com.fk.societymanagementapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.text.TextUtilsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.CharArrayBuffer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.CharBuffer;
import java.util.ArrayList;

public class ChairmandashActivity extends AppCompatActivity {

    int im[]={R.color.design_default_color_background,R.color.design_default_color_background,R.color.design_default_color_background,R.color.design_default_color_background};
    int img[]={R.mipmap.members,R.mipmap.notice,R.mipmap.eventsss,R.mipmap.complaint};
    String title[]={"Members","Notice","Events","Complaints"};

    ArrayList<Admindash> al=new ArrayList<>();

    Toolbar toolbar;

RecyclerView revdash;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chairmandash);

        toolbar=findViewById(R.id.admin_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Dashboard");

        revdash=findViewById(R.id.revdash);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(ChairmandashActivity.this);
        revdash.setLayoutManager(layoutManager);

        al.clear();
for (int i=0;i<im.length;i++){
    Admindash ad=new Admindash(im[i],img[i],title[i]);
    al.add(ad);
}
MyAdapterAdmin adapter=new MyAdapterAdmin(ChairmandashActivity.this,al);
revdash.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_logout,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.logout)
        {
            Intent i=new Intent(ChairmandashActivity.this,MainActivity.class);
            finish();
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(ChairmandashActivity.this)
                .setTitle("Logout")
                .setMessage("you will be logout from the session")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show()
                .setCancelable(false);
    }
}