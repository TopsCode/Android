package com.fk.societymanagementapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class complaintsAdapter extends RecyclerView.Adapter<complaintsAdapter.Myclass> {
    Context context;
    List<complaints> complaintsList;
    ApiInterface apiInterface;

    public complaintsAdapter(Context context, List<complaints> complaintsList) {
        this.context = context;
        this.complaintsList = complaintsList;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.complaintslayout,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass holder, int position) {
    final complaints co=complaintsList.get(position);
    holder.id.setText(co.getId());
    holder.name.setText(co.getName());
    holder.bname.setText(co.getBuilding_name());
    holder.room.setText(co.getRoom_no());
    holder.subject.setText(co.getSubject());
    holder.desc.setText(co.getDescription());

    holder.btnsubmit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String id= co.getId();
            Log.d("mydata","id ---> "+id);
            Toast.makeText(context, "id = "+id, Toast.LENGTH_SHORT).show();
            Call<complaints> call=apiInterface.updatestatus(id);
            call.enqueue(new Callback<complaints>() {
                @Override
                public void onResponse(Call<complaints> call, Response<complaints> response) {
                    complaints co=response.body();
                    Toast.makeText(context, "approved", Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onFailure(Call<complaints> call, Throwable t) {
                    Toast.makeText(context, ""+t.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d("mydata","error :"+t.getMessage());
                }
            });
        }
    });

    }

    @Override
    public int getItemCount() {
        return complaintsList.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        TextView name,bname,room,subject,desc,id;
        androidx.appcompat.widget.AppCompatButton btnsubmit;

        public Myclass(@NonNull View itemView) {
            super(itemView);

            name=itemView.findViewById(R.id.name);
            bname=itemView.findViewById(R.id.bname);
            room=itemView.findViewById(R.id.room);
            subject=itemView.findViewById(R.id.subject);
            desc=itemView.findViewById(R.id.desc);
            btnsubmit=itemView.findViewById(R.id.btnsubmit);
            id=itemView.findViewById(R.id.idcomplaint);

            apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);
        }
    }
}
