package com.fk.societymanagementapplication;

import com.google.gson.annotations.SerializedName;

public class mymembers {
    @SerializedName("id")
    String id;
    @SerializedName("Name")
String Name;
    @SerializedName("Email")
    String Email;
    @SerializedName("Phone")
    String Phone;
    @SerializedName("Buildingname")
    String Buildingname;
    @SerializedName("Room")
    String Room;
    @SerializedName("Occupation")
    String Occupation;

    public String response;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public mymembers(String id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getBuildingname() {
        return Buildingname;
    }

    public void setBuildingname(String buildingname) {
        Buildingname = buildingname;
    }

    public String getRoom() {
        return Room;
    }

    public void setRoom(String room) {
        Room = room;
    }

    public String getOccupation() {
        return Occupation;
    }

    public String getResponse() {
        return response;
    }

    public void setOccupation(String occupation) {
        Occupation = occupation;
    }

    public mymembers(String name, String email, String phone, String buildingname, String room, String occupation) {

        Name = name;
        Email = email;
        Phone = phone;
        Buildingname = buildingname;
        Room = room;
        Occupation = occupation;
    }
}
