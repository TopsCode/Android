package com.fk.societymanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NoticeActivity extends AppCompatActivity {
EditText etdate,ettitle,etdetail;
Button btnpost,btnviewnotice;

ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        etdate=findViewById(R.id.etdate);
        ettitle=findViewById(R.id.ettitle);
        etdetail=findViewById(R.id.etdetail);
        btnpost=findViewById(R.id.btnpost);
        btnviewnotice=findViewById(R.id.btnviewnotice);

        btnviewnotice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm =getSupportFragmentManager();
                NoticeFragment fragment=new NoticeFragment();
                fm.beginTransaction().replace(R.id.noticeact, fragment).commit();
            }
        });



        btnpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Call<notice> call=apiInterface.postnotice(etdate.getText().toString(),ettitle.getText().toString(),etdetail.getText().toString());
                call.enqueue(new Callback<notice>() {
                    @Override
                    public void onResponse(Call<notice> call, Response<notice> response) {
                        notice no=response.body();
                        Toast.makeText(NoticeActivity.this, "Posted Successfully", Toast.LENGTH_SHORT).show();

                        Intent i=new Intent(NoticeActivity.this,ChairmandashActivity.class);
                        startActivity(i);
                    }

                    @Override
                    public void onFailure(Call<notice> call, Throwable t) {

                    }
                });
            }
        });


    }
}