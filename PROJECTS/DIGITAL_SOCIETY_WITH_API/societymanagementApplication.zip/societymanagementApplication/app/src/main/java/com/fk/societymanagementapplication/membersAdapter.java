package com.fk.societymanagementapplication;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class membersAdapter extends RecyclerView.Adapter<membersAdapter.Myclass> {
    Context context;
    List<mymembers> mymembersList;

    public membersAdapter(Context context, List<mymembers> mymembersList) {
        this.context = context;
        this.mymembersList = mymembersList;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.memberslayout,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Myclass holder, int position) {
        holder.txtid.setText(mymembersList.get(position).getId());
    holder.txtname.setText(mymembersList.get(position).getName());
    holder.txtemail.setText(mymembersList.get(position).getEmail());
    holder.txtphone.setText(mymembersList.get(position).getPhone());
    holder.txtbuilding.setText(mymembersList.get(position).getBuildingname());
    holder.txtroom.setText(mymembersList.get(position).getRoom());
    holder.txtoccupation.setText(mymembersList.get(position).getOccupation());
    holder.txtnameview.setText(mymembersList.get(position).getName());
    holder.txtoccupationview.setText(mymembersList.get(position).getOccupation());
    holder.imgcall.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(Intent.ACTION_CALL);
            i.setData(Uri.parse("tel:"+holder.txtphone.getText().toString()));
            context.startActivity(i);
        }
    });
    holder.imgadd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(ContactsContract.Intents.Insert.ACTION);
            i.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            i.putExtra(ContactsContract.Intents.Insert.NAME,holder.txtname.getText().toString());
            i.putExtra(ContactsContract.Intents.Insert.PHONE,holder.txtphone.getText().toString());
            i.putExtra(ContactsContract.Intents.Insert.COMPANY,holder.txtoccupation.getText().toString());
            context.startActivity(i);
        }
    });

    holder.fulldetail.setVisibility(View.INVISIBLE);
    holder.viewless.setVisibility(View.INVISIBLE);

    holder.viewmore.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            holder.fulldetail.setVisibility(View.VISIBLE);
            holder.viewmore.setVisibility(View.INVISIBLE);
            holder.viewless.setVisibility(View.VISIBLE);
        }
    });
    holder.viewless.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            holder.fulldetail.setVisibility(View.INVISIBLE);
            holder.viewmore.setVisibility(View.VISIBLE);
            holder.viewless.setVisibility(View.INVISIBLE);

        }
    });

    }

    @Override
    public int getItemCount() {
        return mymembersList.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        TextView txtid,txtname,txtemail,txtphone,txtbuilding,txtroom,txtoccupation,txtoccupationview,txtnameview;
        ImageView imgcall,imgadd,viewmore,viewless;
        CardView fulldetail;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgcall=itemView.findViewById(R.id.imgcall);
            txtid=itemView.findViewById(R.id.txtid);
            txtname=itemView.findViewById(R.id.txtname);
            txtemail=itemView.findViewById(R.id.txtemail);
            txtphone=itemView.findViewById(R.id.txtphone);
            txtbuilding=itemView.findViewById(R.id.txtbuilding);
            txtroom=itemView.findViewById(R.id.txtroom);
            txtoccupation=itemView.findViewById(R.id.txtoccupation);
            imgadd=itemView.findViewById(R.id.imgadd);
            viewmore=itemView.findViewById(R.id.viewmore);
            viewless=itemView.findViewById(R.id.viewless);
            fulldetail=itemView.findViewById(R.id.fulldetail);
            txtoccupationview=itemView.findViewById(R.id.txtoccupationview);
            txtnameview=itemView.findViewById(R.id.txtnameview);

        }
    }
}
