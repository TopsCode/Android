package com.fk.societymanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class NewRegActivity extends AppCompatActivity {

    TextView tvv;
    EditText edname,edemail,edphone,edbuilding,edroom,edoccupation;
    Button btns;

    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21){
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        setContentView(R.layout.activity_main2);
        setTitle("New Registration");

        tvv=findViewById(R.id.tvv);
        edname=findViewById(R.id.edname);
        edemail=findViewById(R.id.edemail);
        edphone=findViewById(R.id.edphone);
        edbuilding=findViewById(R.id.edbuilding);
        edroom=findViewById(R.id.edroom);
        edoccupation=findViewById(R.id.edoccupation);

        changeStatusBarColor();

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        btns=findViewById(R.id.btns);

        btns.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                final Call<mymembers> call=apiInterface.registeruser(edname.getText().toString(),edemail.getText().toString(),edphone.getText().toString(),edbuilding.getText().toString(),edroom.getText().toString(),edoccupation.getText().toString());
                String Name=edname.getText().toString();
                String Email=edemail.getText().toString();
                String Phone= edphone.getText().toString();
                String Building= edbuilding.getText().toString();
                String Room=edroom.getText().toString();
                String Occupation=edoccupation.getText().toString();

                if(TextUtils.isEmpty(Name)){
                    edname.setError("this fiels is mendatory");
                }if (TextUtils.isEmpty(Email)){
                    edemail.setError("this fiels is mendatory");
                }if (TextUtils.isEmpty(Phone)){
                    edphone.setError("this fiels is mendatory");
                }if (TextUtils.isEmpty(Building)){
                    edbuilding.setError("this fiels is mendatory");
                }if (TextUtils.isEmpty(Room)){
                    edroom.setError("this fiels is mendatory");
                }if (TextUtils.isEmpty(Occupation)){
                    edoccupation.setError("this field is mendatory");
                }else{
                call.enqueue(new Callback<mymembers>() {
                    @Override
                    public void onResponse(Call<mymembers> call, Response<mymembers> response) {
                        mymembers my=response.body();
                        Toast.makeText(NewRegActivity.this, ""+my.getResponse(), Toast.LENGTH_SHORT).show();
                        
                            Intent intent=new Intent(NewRegActivity.this,MainActivity.class);
                            startActivity(intent);
                    }

                    @Override
                    public void onFailure(Call<mymembers> call, Throwable t) {

                    }
                });
                }
            }
        });

    }

    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }
    }
}