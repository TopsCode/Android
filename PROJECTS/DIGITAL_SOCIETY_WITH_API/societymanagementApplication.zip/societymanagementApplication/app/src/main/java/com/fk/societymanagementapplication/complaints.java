package com.fk.societymanagementapplication;

import com.google.gson.annotations.SerializedName;

public class complaints {
    @SerializedName("id")
    String id;
    @SerializedName("name")
    String name;
    @SerializedName("building_name")
    String building_name;
    @SerializedName("room_no")
    String room_no;
    @SerializedName("subject")
    String subject;
    @SerializedName("description")
    String description;
    @SerializedName("status")
    String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String Response;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuilding_name() {
        return building_name;
    }

    public void setBuilding_name(String building_name) {
        this.building_name = building_name;
    }

    public String getRoom_no() {
        return room_no;
    }

    public void setRoom_no(String room_no) {
        this.room_no = room_no;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResponse() {
        return Response;
    }

    public complaints(String id, String name, String building_name, String room_no, String subject, String description, String status) {
        this.id = id;
        this.name = name;
        this.building_name = building_name;
        this.room_no = room_no;
        this.subject = subject;
        this.description = description;
        this.status=status;
    }
}
