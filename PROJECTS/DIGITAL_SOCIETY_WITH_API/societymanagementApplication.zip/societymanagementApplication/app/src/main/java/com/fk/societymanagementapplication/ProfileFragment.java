package com.fk.societymanagementapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;


public class ProfileFragment extends Fragment {


    Myshared mysp;
    HashMap hm=new HashMap();

    String result;
    ApiInterface apiInterface;
    List<mymembers> mymembersList;

    TextView name,email,phone,building,room,occupation,id,tvname;

    Button btn_update;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvname=view.findViewById(R.id.tvname);
        id=view.findViewById(R.id.id);
        name=view.findViewById(R.id.name);
        email=view.findViewById(R.id.email);
        phone=view.findViewById(R.id.phone);
        building=view.findViewById(R.id.building);
        room=view.findViewById(R.id.room);
        occupation=view.findViewById(R.id.occupation);
        btn_update=view.findViewById(R.id.btn_update);

        mysp=new Myshared(getContext());
        hm=mysp.getData();
        result= (String) hm.get(Myshared.KEYDATA);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        Call<List<mymembers>> call = apiInterface.getuser(result);

        call.enqueue(new Callback<List<mymembers>>() {
            @Override
            public void onResponse(Call<List<mymembers>> call, Response<List<mymembers>> response) {
                mymembersList=response.body();
                id.setText(result);
                name.setText(mymembersList.get(0).getName());
                email.setText(mymembersList.get(0).getEmail());
                phone.setText(mymembersList.get(0).getPhone());
         //       Toast.makeText(getContext(), "building name "+mymembersList.get(0).getBuildingname(), Toast.LENGTH_SHORT).show();
                building.setText(mymembersList.get(0).getBuildingname());
                room.setText(mymembersList.get(0).getRoom());
                occupation.setText(mymembersList.get(0).getOccupation());
                tvname.setText(mymembersList.get(0).getName());
            }

            @Override
            public void onFailure(Call<List<mymembers>> call, Throwable t) {

            }
        });

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "clicked", Toast.LENGTH_SHORT).show();
                final Call<mymembers> call1=apiInterface.updatemembers(id.getText().toString(),name.getText().toString(),email.getText().toString(),phone.getText().toString(),building.getText().toString(),room.getText().toString(),occupation.getText().toString());
                call1.enqueue(new Callback<mymembers>() {
                    @Override
                    public void onResponse(Call<mymembers> call, Response<mymembers> response) {

                        mymembers my=response.body();
                        Toast.makeText(getContext(), "Update Successfully"+response.message(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onFailure(Call<mymembers> call, Throwable t) {
                        Toast.makeText(getContext(), "fail"+t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });




       // Toast.makeText(getContext(), "profile : id "+result, Toast.LENGTH_SHORT).show();

    }
}