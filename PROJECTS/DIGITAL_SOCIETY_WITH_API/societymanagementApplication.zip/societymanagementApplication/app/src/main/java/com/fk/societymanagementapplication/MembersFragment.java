package com.fk.societymanagementapplication;

import android.Manifest;
import android.content.Context;
import android.icu.text.CaseMap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;


public class MembersFragment extends Fragment {

    RecyclerView recv;
    ApiInterface apiInterface;
    List<mymembers> mymembersList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_members, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recv=view.findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getContext());
        recv.setLayoutManager(layoutManager);

        ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.CALL_PHONE,Manifest.permission.WRITE_CONTACTS},1);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        Call<List<mymembers>> call=apiInterface.getmembers();

        call.enqueue(new Callback<List<mymembers>>() {
            @Override
            public void onResponse(Call<List<mymembers>> call, Response<List<mymembers>> response) {
                mymembersList=response.body();
                membersAdapter adapter=new membersAdapter(getContext(),mymembersList);
                recv.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<mymembers>> call, Throwable t) {
            }
        });
    }
}