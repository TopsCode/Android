package com.fk.societymanagementapplication;

import com.google.gson.annotations.SerializedName;

public class myevents {
    @SerializedName("id")
    String id;
    @SerializedName("Date")
    String Date;
    @SerializedName("Event_name")
    String Event_name;
    @SerializedName("Description")
    String Description;

    public String response;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getEvent_name() {
        return Event_name;
    }

    public void setEvent_name(String event_name) {
        Event_name = event_name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getResponse() {
        return response;
    }

    public myevents(String id, String date, String event_name, String description) {
        this.id = id;
        Date = date;
        Event_name = event_name;
        Description = description;
    }
}
