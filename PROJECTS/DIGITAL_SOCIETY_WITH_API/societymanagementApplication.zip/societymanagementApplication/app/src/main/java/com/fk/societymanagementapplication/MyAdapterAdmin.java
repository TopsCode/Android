package com.fk.societymanagementapplication;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapterAdmin extends RecyclerView.Adapter<MyAdapterAdmin.Myclass> {
    Context context;
    ArrayList<Admindash> admindashes;

    public MyAdapterAdmin(Context context, ArrayList<Admindash> admindashes) {
        this.context = context;
        this.admindashes = admindashes;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v=LayoutInflater.from(parent.getContext()).inflate(R.layout.admindata,parent,false);

        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, final int position) {
    Admindash a=admindashes.get(position);
    holder.imgbg.setImageResource(a.getBg());
    holder.imglogo.setImageResource(a.getAg());
    holder.txt.setText(a.getTitle());
    holder.imgbg.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//            if (position==0){
//                Intent i=new Intent(context,ProfileActivity.class);
//                context.startActivity(i);
            if (position==0){
                Intent i=new Intent(context,MembersActivity.class);
                context.startActivity(i);
            }if (position==1) {
                Intent i = new Intent(context, NoticeActivity.class);
                context.startActivity(i);
            }if (position==2){
                Intent i=new Intent(context,EventsActivity.class);
                context.startActivity(i);
        }if (position==3){
                Intent i = new Intent(context, ComplaintsActivity.class);
                context.startActivity(i);
            }
        }
    });
    }

    @Override
    public int getItemCount() {
        return admindashes.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgbg;
        ImageView imglogo;
        TextView txt;

        public Myclass(@NonNull View itemView) {
            super(itemView);

        imgbg=itemView.findViewById(R.id.imgbg);
        imglogo=itemView.findViewById(R.id.imglogo);
        txt=itemView.findViewById(R.id.txt);
        }
    }
}
