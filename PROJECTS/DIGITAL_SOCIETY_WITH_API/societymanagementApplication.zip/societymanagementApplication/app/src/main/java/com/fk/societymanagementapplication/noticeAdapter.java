package com.fk.societymanagementapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class noticeAdapter extends RecyclerView.Adapter<noticeAdapter.Myclass> {
    Context context;
    List<notice> notices;
    ApiInterface apiInterface;

    public noticeAdapter(Context context, List<notice> notices) {
        this.context = context;
        this.notices = notices;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.notice_layout,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
final notice no=notices.get(position);
holder.id.setText(no.getId());
holder.ndate.setText(no.getDate());
holder.ntitle.setText(no.getTitle());
holder.ndesc.setText(no.getDesc());
holder.delete.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (!notices.isEmpty()) {
            new AlertDialog.Builder(context)
                    .setTitle("Are you sure?")
                    .setMessage("This notice will be deleted permanently.")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Call<notice> call1 = apiInterface.deletenotice(notices.get(0).getId());
                            call1.enqueue(new Callback<notice>() {
                                @Override
                                public void onResponse(Call<notice> call, Response<notice> response) {
                                    notice no = response.body();
//                                Toast.makeText(context, ""+no.getId(), Toast.LENGTH_SHORT).show();
                                    Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onFailure(Call<notice> call, Throwable t) {
                                    Toast.makeText(context, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });

                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    })
                    .show()
                    .setCancelable(false);

        }else
        {
            Toast.makeText(context, "No notices found", Toast.LENGTH_SHORT).show();
        }
    }
});
    }

    @Override
    public int getItemCount() {
        return notices.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        TextView ndate,ntitle,ndesc,id;
        ImageView delete;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            ndate=itemView.findViewById(R.id.ndate);
            ntitle=itemView.findViewById(R.id.ntitle);
            ndesc=itemView.findViewById(R.id.ndesc);
            delete=itemView.findViewById(R.id.delete);
            id=itemView.findViewById(R.id.id);

            apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);

        }
    }
}
