package com.fk.societymanagementapplication;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("get_data.php")
    Call<List<mymembers>> getmembers();

    @FormUrlEncoded
    @POST("register.php")
    Call<mymembers> registeruser(@Field("Name") String Name,
                                 @Field("Email") String Email,
                                 @Field("Phone") String Phone,
                                 @Field("Buildingname") String Buildingname,
                                 @Field("Room") String Room,
                                 @Field("Occupation") String Occupation);

    @GET("get_event.php")
    Call<List<myevents>> getevents();

    @FormUrlEncoded
    @POST("event.php")
    Call<myevents> postevent(@Field("Date") String Date,
                             @Field("Event_name") String Event_name,
                             @Field("Description") String Description);

    @GET("login.php")
    Call<List<mymembers>> getspecificuser(@Query("Name") String Name,
                                          @Query("Phone") String Phone);

    @GET("get_by_id.php")
    Call<List<mymembers>> getuser(@Query("id") String id);



    @GET("get_complaints.php")
    Call<List<complaints>> getcomplaints();

    @FormUrlEncoded
    @POST("complaints.php")
    Call<complaints> postcomplaints(@Field("name") String name,
                                          @Field("building_name") String building_name,
                                          @Field("room_no") String room_no,
                                          @Field("subject") String subject,
                                          @Field("description") String description);

    @GET("get_notice.php")
    Call<List<notice>> getnotice();

    @FormUrlEncoded
    @POST("notice.php")
    Call<notice> postnotice(@Field("date") String date,
                            @Field("title") String title,
                            @Field("description") String description);

     @FormUrlEncoded
    @POST("updatedata.php")
    Call<mymembers> updatemembers(@Field("id") String id,
                                  @Field("Name") String Name,
                                  @Field("Email") String Email,
                                  @Field("Phone") String Phone,
                                  @Field("Buildingname") String Buildingname,
                                  @Field("Room") String Room,
                                  @Field("Occupation") String Occupation);


    @FormUrlEncoded
    @POST("delete_notice.php")
    Call<notice> deletenotice(@Field("id") String id);


    @FormUrlEncoded
    @POST("update_status.php")
    Call<complaints> updatestatus(@Field("id") String id);

}
