package com.fk.societymanagementapplication;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.List;


public class NoticeFragment extends Fragment {

    RecyclerView recv;
    ApiInterface apiInterface;

    List<notice> notices;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_notice, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recv=view.findViewById(R.id.recv);


        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getContext());
        recv.setLayoutManager(layoutManager);

        apiInterface=ApiClient.getRetrofit().create(ApiInterface.class);
        Call<List<notice>> call=apiInterface.getnotice();

        call.enqueue(new Callback<List<notice>>() {
            @Override
            public void onResponse(Call<List<notice>> call, Response<List<notice>> response) {
                notices=response.body();
//                Toast.makeText(getContext(), ""+notices.get(0).getId(), Toast.LENGTH_SHORT).show();
                noticeAdapter adapter=new noticeAdapter(getContext(),notices);
                recv.setAdapter(adapter);
                recv.notifyAll();
            }

            @Override
            public void onFailure(Call<List<notice>> call, Throwable t) {

            }
        });

    }
}