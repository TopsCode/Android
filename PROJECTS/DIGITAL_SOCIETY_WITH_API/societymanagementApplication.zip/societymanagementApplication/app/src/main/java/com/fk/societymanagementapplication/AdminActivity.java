package com.fk.societymanagementapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AdminActivity extends AppCompatActivity {

    TextView tvch,tvw;
    EditText etuserc,etpassc;
    ImageView btnch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT>=21)
        {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        setContentView(R.layout.activity_admin);


        setTitle("Admin Login");

        tvch=findViewById(R.id.tvch);
        tvw=findViewById(R.id.tvw);
        etuserc=findViewById(R.id.etuserc);
        etpassc=findViewById(R.id.etpassc);
        btnch=findViewById(R.id.btnch);

        changeStatusBarColor();

        btnch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user=etuserc.getText().toString();
                String pass=etpassc.getText().toString();

                etuserc.getText().clear();
                etpassc.getText().clear();

                if (user.equals("A") && pass.equals("a")) {
                    Intent intent = new Intent(AdminActivity.this, ChairmandashActivity.class);
                    startActivity(intent);

                }else if (TextUtils.isEmpty(pass)){
                    etpassc.setError("enter password");
                }else if (TextUtils.isEmpty(user)){
                    etuserc.setError("enter Username");
                }else {
                    Toast.makeText(AdminActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    private void changeStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }
    }
}