package com.fk.societymanagementapplication;

public class Admindash {
    int bg;
    int ag;
    String title;

    public int getBg() {
        return bg;
    }

    public void setBg(int bg) {
        this.bg = bg;
    }

    public int getAg() {
        return ag;
    }

    public void setAg(int ag) {
        this.ag = ag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Admindash(int bg, int ag, String title) {
        this.bg = bg;
        this.ag = ag;
        this.title = title;
    }
}
