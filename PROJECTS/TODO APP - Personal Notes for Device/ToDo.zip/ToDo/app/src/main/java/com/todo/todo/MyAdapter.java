package com.todo.todo;

import android.content.Context;
import android.content.Intent;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.Myclass> {
    Context context;
    ArrayList todo_Title,todo_Desc;

    int position;

    MyAdapter(Context context,ArrayList todo_Title,ArrayList todo_Desc)
    {
        this.context=context;
//        this.todo_id=todo_id;
        this.todo_Title=todo_Title;
        this.todo_Desc=todo_Desc;
    }

    @NonNull
    @Override
    public MyAdapter.Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.recv_layout,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.Myclass holder, int position) {
        this.position=position;
        holder.title.setText(String.valueOf(todo_Title.get(position)));
//        holder.id.setText(String.valueOf(todo_id.get(position)));
        holder.desc.setText(String.valueOf(todo_Desc.get(position)));
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,deleteActivity2.class);
                intent.putExtra("Title", String.valueOf(todo_Title.get(position)));
                intent.putExtra("Description", String.valueOf(todo_Desc.get(position)));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return todo_Title.size();
    }
    class Myclass extends RecyclerView.ViewHolder  {
        TextView title,desc,id;
        CardView layout;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.title);
//            id=itemView.findViewById(R.id.id);
            desc=itemView.findViewById(R.id.desc);
            layout=itemView.findViewById(R.id.layout);
        }
    }
}
