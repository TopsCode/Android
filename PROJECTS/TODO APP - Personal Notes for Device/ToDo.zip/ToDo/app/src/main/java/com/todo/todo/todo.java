package com.todo.todo;

public class todo {
    String id;
    String Title;
    String Desc;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String desc) {
        Desc = desc;
    }

    public todo(String id, String title, String desc) {
        this.id = id;
        Title = title;
        Desc = desc;
    }
}
