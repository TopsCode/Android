package com.todo.todo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.HashMap;

public class deleteActivity2 extends AppCompatActivity {
Mydatabase mydatabase;

Toolbar toolbar;

EditText edtitle,eddesc;
Button update;
ImageView delete;

String title,desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete2);

        toolbar=findViewById(R.id.delete_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Notes");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        mydatabase=new Mydatabase(deleteActivity2.this);

        edtitle=findViewById(R.id.edtitle);
        eddesc=findViewById(R.id.eddesc);
        delete=findViewById(R.id.delete);
        update=findViewById(R.id.update);

        getdata();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydatabase.updatedata(edtitle.getText().toString(),eddesc.getText().toString());
                Intent i=new Intent(deleteActivity2.this,MainActivity.class);
                finish();
                startActivity(i);
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydatabase.deletedata(edtitle.getText().toString());
                Intent i=new Intent(deleteActivity2.this,MainActivity.class);
                finish();
                startActivity(i);
            }
        });
    }
    void getdata()
    {
        if (getIntent().hasExtra("Title") && getIntent().hasExtra("Description"))
        {
            title=getIntent().getStringExtra("Title");
            desc=getIntent().getStringExtra("Description");

            edtitle.setText(title);
            eddesc.setText(desc);
        }
    }
}