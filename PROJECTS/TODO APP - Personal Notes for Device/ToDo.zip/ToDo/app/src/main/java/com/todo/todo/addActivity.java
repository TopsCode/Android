package com.todo.todo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class addActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_SUPPORT_INPUT = 1000;
    EditText edtitle,eddesc;
    Button btnadd;
    ImageView speak;
    Toolbar toolbar;

    Mydatabase mydatabase;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        speak=findViewById(R.id.speak);

        toolbar=findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("To-do");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mydatabase=new Mydatabase(addActivity.this);

        edtitle=findViewById(R.id.edtitle);
        eddesc=findViewById(R.id.eddesc);
        btnadd=findViewById(R.id.btnadd);

        speak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                youspeak();
            }
        });



        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=edtitle.getText().toString();
                String desc=eddesc.getText().toString();
                if (TextUtils.isEmpty(title))
                {
                    edtitle.setError("please add Title");
                if (TextUtils.isEmpty(desc)) {
                    eddesc.setError("please add to-do");
                }
                }else {
                    mydatabase.inserdata(edtitle.getText().toString(), eddesc.getText().toString());
                    c = mydatabase.getlist();
                    if (c.getCount() > 0) {
                        Intent i = new Intent(addActivity.this, MainActivity.class);
                        startActivity(i);
                        finish();
                    }
                }
            }
        });
    }
public  void youspeak()
{
Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Hello speak your to-do!");

try
{
    startActivityForResult(i,REQUEST_CODE_SUPPORT_INPUT);
}
catch (Exception e)
{
    Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
}
}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode)
        {
            case REQUEST_CODE_SUPPORT_INPUT:
            {
            if (resultCode==RESULT_OK && null!=data)
                {
                 ArrayList<String> result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                 eddesc.setText(result.get(0));
                }
            break;
            }
        }
    }
}