package com.todo.todo;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class Myshared {
    public static final String KEYDATA="DATA";
    Context context;
    SharedPreferences sp;
    SharedPreferences.Editor editor;

    public Myshared(Context context) {
        this.context = context;
        sp=context.getSharedPreferences("MYPREF",Context.MODE_PRIVATE);
    }
    public void addData(int title){
        editor=sp.edit();
        editor.putString(KEYDATA, String.valueOf(title));
        editor.commit();
    }
    public HashMap<String,String> getData()
    {
        HashMap hm=new HashMap();
        hm.put(KEYDATA,sp.getString(KEYDATA,"DEFAULT"));
        return hm;
    }
    public void clearData()
    {
        editor=sp.edit();
        editor.clear();
        editor.commit();
    }
}
