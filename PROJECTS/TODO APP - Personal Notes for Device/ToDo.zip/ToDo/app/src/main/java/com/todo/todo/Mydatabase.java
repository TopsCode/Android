package com.todo.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Mydatabase extends SQLiteOpenHelper {
    Context context;
    SQLiteDatabase db=this.getWritableDatabase();

    public Mydatabase(@Nullable Context context) {
        super(context, "todo", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
db.execSQL("create table list(id integer primary key autoincrement,Title varchar(20),Description varchar(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public  void inserdata(String title,String description){

        ContentValues cv=new ContentValues();
        cv.put("Title",title);
        cv.put("Description",description);
        db.insert("list",null,cv);
    }
    public Cursor getlist()
    {
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("select * from list",null);
        return c;
    }
    public void deletedata(String title)
    {
this.getWritableDatabase().delete("list","Title='"+title+"'",null);
    }
    public void updatedata(String title,String new_description)
    {
        this.getWritableDatabase().execSQL("update list set Description='"+new_description+"' where Title='"+title+"'");
    }

}
