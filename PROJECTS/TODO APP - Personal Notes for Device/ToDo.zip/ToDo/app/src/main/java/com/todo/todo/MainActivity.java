package com.todo.todo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    RecyclerView recv;
    ArrayList<String> todo_id,todo_Title,todo_Desc;

    FloatingActionButton addtodo;

    TextView txtlove;

    Toolbar mytoolbar;

    Mydatabase mydatabase;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtlove=findViewById(R.id.txtlove);

        mytoolbar=findViewById(R.id.my_toolbar);
        setSupportActionBar(mytoolbar);
        getSupportActionBar().setTitle("All To-dos");

        addtodo=findViewById(R.id.addtodo);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(MainActivity.this);
        recv.setLayoutManager(layoutManager);

        mydatabase=new Mydatabase(MainActivity.this);

        todo_Title=new ArrayList<>();
        todo_Desc=new ArrayList<>();

        showData();     //method called here.

        MyAdapter adapter=new MyAdapter(MainActivity.this,todo_Title,todo_Desc);
        recv.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        addtodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,addActivity.class);
                startActivity(i);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    void showData()
    {
        c=mydatabase.getlist();
        if (c.getCount()==0)
        {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }else
        {
            while(c.moveToNext())
            {
                todo_Title.add(c.getString(1));
                todo_Desc.add(c.getString(2));
            }
        }
    }
}