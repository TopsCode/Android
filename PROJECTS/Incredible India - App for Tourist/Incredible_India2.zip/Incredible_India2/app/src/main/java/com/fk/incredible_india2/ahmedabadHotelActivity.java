package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class ahmedabadHotelActivity extends AppCompatActivity {
    RecyclerView recvv;


    int im[]={R.mipmap.hyaat,R.mipmap.double_tree,R.mipmap.novotel,R.mipmap.crownplaza};
    String title[]={"Hyatt Regency","Double Tree by Hilton","Novotel Hotel","Crown Plaza"};
    String add[]={"17A, Ashram Road, Usmanpura, Ahmedabad","Ambli Bopal Road, Vikram Nagar Ahmedabad","Next to Wide Angle Cinema, ISCON cross road, S.G. Highway Ahmedabad"," S. G. Road near Shapath - V Ahmedabad"};

    ArrayList<hotel> al=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ahmedabad_hotel);
        setTitle("Hotels");

        recvv=findViewById(R.id.recvv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(ahmedabadHotelActivity.this);
        recvv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(ahmedabadHotelActivity.this,al);
        recvv.setAdapter(adapter);
    }
}