package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class splashActivity extends AppCompatActivity implements Runnable {
    TextView tvv;

    Animation top_animation,bottom_animation;
    ImageView img;
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        top_animation= AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottom_animation= AnimationUtils.loadAnimation(this,R.anim.bottom_animation);

        img=findViewById(R.id.img);
        tvv=findViewById(R.id.tvv);
        txt=findViewById(R.id.txt);

        img.setAnimation(top_animation);
        // txt.setAnimation(bottom_animation);
        tvv.setAnimation(bottom_animation);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Handler handler=new Handler();
        handler.postDelayed(this,3000);
    }

    @Override
    public void run() {
        Context context=this;
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}