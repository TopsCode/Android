package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class gujarat_adapter extends RecyclerView.Adapter<gujarat_adapter.Myclass> {
    Context context;
    ArrayList<gujarat> gujarats;

    public gujarat_adapter(Context context, ArrayList<gujarat> gujarats) {
        this.context = context;
        this.gujarats = gujarats;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
        gujarat g=gujarats.get(position);
        holder.imgg.setImageResource(g.getBg());
        holder.txtg.setText(g.getTitle());


        holder.btninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (position==0)
                {

                    MyCustomDialog.displayDialog(context, "Founded by Sultan Ahmad Shah in 1411 AD, Ahmedabad, in the state of Gujarat, has grown into one of the most important modern cities of India. Straddling the Sabarmati river, this prosperous city of six million is a delight for archeologists, anthropologists, architects, histsorians, sociologists, traders, bargain hunters, and plain tourists.\n" +
                            "\n" +
                            "An exciting combination of traditions and modernism, Ahmedabad captures all visitors with its diversity of places, religious and ethnic communities. It is interesting to see how Indian atmosphere mix with the colonial British influence, how Hinduism, the world's oldest existing religion develops in the globalising world.\"\n");
                }else if (position==1){
                    MyCustomDialog.displayDialog(context,"Surat is a city located on the western part of India in the state of Gujarat. It is one of the most dynamic city of India with one of the fastest growth rate due to immigration from various part of Gujarat and other states of India.\n" +
                            "\n" +
                            "Surat is one of the cleanest city of India and is also known by several other names like \"THE SILK CITY\", \"THE DIAMOND CITY\", \"THE GREEN CITY\", etc. It has the most vibrant present and an equally varied heritage of the past. It is the city where the British first land in India. The Dutch and the Portuguese also established there business centers in Surat, the remnants of which are still preserved in the modern day Surat. In past this was a glorious port with ships of more than 84 countries anchored in its harbour at any time.\n" +
                            "\n" +
                            "Still today, Surat continues the same tradition as people from all around the country flock in for business and jobs. Surat has practically zero percent unemployment rate and jobs are easier to get here due to very fast development of various industries in and around Surat City.\"\n");
                }else if (position==2){
                    MyCustomDialog.displayDialog(context,"At a distance of 50 km from Mehsana, 129 km from Ahmedabad, 142 km from Mount Abu, 237 km from Vadodara, 251 km from Gandhidham, 260 km from Udaipur, 266 km from Rajkot, 295 km from Bhuj, 345 km from Jamnagar, 366 km from Junagadh, 384 km from Surat, 446 km from Porbandar, 477 km from Dwarka and 672 km from Mumbai, Patan is an ancient fortified city located on the banks of Saraswati River in Gujarat, India. It is one of the popular historical destinations in India and among the top places to visit in Gujarat.\n" +
                            "\n" +
                            "Earlier known as the Anhilwad Patan, the ancient city of Patan was built in 746 AD by Vanraj Chavda, the prominent king of Chavda dynasty. Legend has it that he laid the foundation at the place pointed out by Anahil, a shepherd friend from his younger days, and named the city after him. The city was the capital of Gujarat for almost 650 years, from 746-1411 CE. The town flourished during the Solanki dynasty in the 8th-11th century. .....\n" +
                            "\n");
                }else if (position==3){
                    MyCustomDialog.displayDialog(context,"At a distance of 59 km from Gandhidham, 64 km from Mandvi, 78 km from Kutch, 232 km from Rajkot, 256 km from Jamnagar, 333 km from Junagadh, 334 km from Ahmedabad, 390 km from Dwarka, 431 km from Vadodara, 434 km from Mount Abu, 444 km from Bhavnagar, 557 km from Udaipur and 863 km from Mumbai, Bhuj is a flourishing city in Gujarat and also the headquarters of Kutch district. Often called as the Jaisalmer of Gujarat, Bhuj is one of the popular places to visit in Gujarat and among the best attraction not to miss in a Gujarat tour packages.\n" +
                            "\n" +
                            "Located in the western part of India, Bhuj is the most important city in the Kutch region of Gujarat and also the capital of the former princely state of Kutch. The city of Bhuj got its name from the Bhujiyo Dungar, a hill that overlooks the city and believed to be the residence of the Great Serpent Bhujang, to whom a temple stands at the top of the hill. .....\n" +
                            "\n");
                }else if (position==4){
                    MyCustomDialog.displayDialog(context,"At a distance of 54 km from Gir National Park, 91 km from Somnath, 99 km from Amreli, 103 km from Rajkot, 107 km from Porbandar, 139 km from Jamnagar, 147 km from Diu, 209 km from Dwarka, 289 km from Gandhidham, 319 km from Ahmedabad, 333 km from Bhuj and 388 km from Vadodara, Junagadh is a historical city located in the western Indian state of Gujarat. It is the seventh largest city in Gujarat and among the popular places of heritage in Gujarat.\n" +
                            "\n" +
                            "Located in the foothills of the Mount Girnar, the literal meaning of the term 'Junagadh' is 'old fort' which derives from Uparkot, an ancient fort built in the 4th century CE on a plateau in the middle of the town. It was also termed as 'Yonagadh,' which means 'City of the Greeks,' as it was once ruled by the Greeks. Junagadh is also known as 'Sorath', the name of the princely state that existed before the partition of India and Pakistan in the year 1947.");
                }else if (position==5){
                    MyCustomDialog.displayDialog(context,"At a distance of 10 km from Borgaon, 41 km from Ahwa,77 km from Nashik, 129 km from Mandvi, 160 km from Shirdi, 160 km from Surat, 262 km from Mumbai, 287 km from Vadodara, 288 km from Pune, 398 km from Ahmedabad, 421 km from Gandhinagar, 582 km from Rajkot, 673 km from Jamnagar, 680 km from Junagadh, 763 km from Porbandar, 776 km from Somnath, and 805 km from Dwarka, Saputara is a small hill station in Dang district of Gujarat. Positioned on the Maharashtra- Gujarat border, it is one of the most popular tourist places to visit near Mumbai and among must visit places as part of Gujarat tour packages.");
                }else if (position==6){
                    MyCustomDialog.displayDialog(context,"At a distance of 109 km from Ahmedabad, 132 km from Gandhinagar, 146 km from Surat, 192 km from Bhavnagar, 296 km from Rajkot, 339 km from Indore, 345 km from Udaipur, 386 km from Jamnagar, 396 km from Junagadh, 395 km from Gandhidham, 433 km from Mumbai, 447 km from Somnath, 476 km from Porbandar, 439 km from Bhuj, and 518 km from Dwarka, Vadodara is a beautiful city in the western Indian state of Gujarat. Located on the banks of Vishwamitri River, Vadodara is one of the popular tourist destinations in Gujarat and among the top attractions you must include in Gujarat packages.\n" +
                            "\n" +
                            "Formerly called as Baroda, Vadodara is the third largest city in Gujarat, after Ahmedabad and Surat. Home to some of the most exemplary display of architecture, the tinsel town of Vadodara is the brainchild of Sayaji Rao Gaekwad III, a Maratha ruler who laid foundation for premier institutions to make this city an educational, industrial and commercial center. .....");
                }
            }
        });
        holder.btnhotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position==0){
                    Intent i=new Intent(context,ahmedabadHotelActivity.class);
                    context.startActivity(i);
                }else if (position==1){
                    Intent i=new Intent(context,SuratHotelActivity.class);
                    context.startActivity(i);
                }else if (position==2){
                    Intent i=new Intent(context,PatanHotelActivity.class);
                    context.startActivity(i);
                }else if (position==3){
                    Intent i=new Intent(context,BhujHotelActivity.class);
                    context.startActivity(i);
                }else if (position==4){
                    Intent i=new Intent(context,JunagadhHotelActivity.class);
                    context.startActivity(i);
                }else if (position==5){
                    Intent i=new Intent(context,SaputaraHotelActivity.class);
                    context.startActivity(i);
                }else if (position==6){
                    Intent i=new Intent(context,VadodaraHotelActivity.class);
                    context.startActivity(i);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return gujarats.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);
        }
    }
}
