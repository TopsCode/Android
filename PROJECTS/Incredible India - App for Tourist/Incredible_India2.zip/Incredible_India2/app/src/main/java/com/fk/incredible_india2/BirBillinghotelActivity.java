package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class BirBillinghotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.paul};
    String title[]={"Hotel Paul's Manor"};
    String add[]={"Chougan Chowk Bir Billing Tehsil Baijnath District, Chogan, Bir 176077 India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bir_billing);

        recv=findViewById(R.id.recv);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(BirBillinghotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(BirBillinghotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}