package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class kAdapter extends RecyclerView.Adapter<kAdapter.Myclass> {
    Context context;
    ArrayList<kerala> keralas;

    public kAdapter(Context context, ArrayList<kerala> keralas) {
        this.context = context;
        this.keralas = keralas;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
        kerala k=keralas.get(position);
        holder.imgg.setImageResource(k.getBg());
        holder.txtg.setText(k.getTitle());
        holder.btninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position==0){
                    MyCustomDialog.displayDialog(context,"Officially called Alappuzha, Alleppey is a city in the South Indian state of Kerala. Bordering the Laccadive Sea, it is known for its wide network of interlinking, palm-fringed canals called backwaters and rejuvenating Ayurvedic resorts.");
                }if (position==1){
                    MyCustomDialog.displayDialog(context,"Theyyam is a popular ritual form of worship in Kerala and Karnataka, India. Theyyam consisted of several thousand-year-old traditions, rituals and customs. The performers of Theyyam belong to the lower caste community in ancient caste structure formed by Namboothiri brahmins in Kerala, and have an important position in Theyyam. The people of these districts consider Theyyam itself as a channel to a God and they thus seek blessings from Theyyam. It is performed by mainly by males, except the Devakoothu theyyam. The Devakoothu is the only Theyyam ritual performed by women.It is performed only on the Thekkumbad Kulom temple.");
                }if (position==2){
                    MyCustomDialog.displayDialog(context,"Ashtamudi Lake (Ashtamudi Kayal), in the Kollam District of the Indian state of Kerala, is the most visited backwater and lake in the state. It possesses a unique wetland ecosystem and a large palm-shaped (also described as octopus-shaped) water body, second only in size to the Vembanad estuary ecosystem of the state.");
                }if (position==3){
                    MyCustomDialog.displayDialog(context,"\n" +
                            "Poovar is a tourist town in Neyyattinkara in the Thiruvananthapuram district of Kerala state, South India. This village is almost at the southern tip of Thiruvananthapuram while the next village, Pozhiyoor, marks the end of Kerala. This village beach attracts tourists throughout the year. The beach is magnificent and has many 5 star hotels and Island hotels to attract more and more tourists. This will eventually contribute more development of the region.");
                }if (position==4){
                    MyCustomDialog.displayDialog(context,"Mararikulam is connected by rail and has a railway station by the same name. It is also well connected by road. NH 66 passes through S.L.Puram, which is 5 km to the east of Mararikulam. Nearest airport is Cochin International Airport. It was rated as one of the worlds top five HAMMOCK BEACH by National Geographic survey. & The CGH Marari beach resorts has made it to the \"Sense of Place\" final list of National Geographic Traveller \"WORLD LEGACY AWARD\" by National Geographic in partnership with ITB Berlin. Marari Beach is being increasingly preferred by travellers as an alternative to its more popular counterpart- Kovalam in the South. Tourists can cover the key highlights of Kerala including the Port town of Cochin, the tea plantations of Munnar, the wildlife in Periyar, the houseboats on the backwaters in Alleppey and end their stay at Marari where they can enjoy the beaches before flying out of Cochin again- instead of having to travel down south to Kovalam for the beaches. The beaches in Marari are conveniently located just an hour and a half away from the Cochin international airport.");
                }if (position==5){
                    MyCustomDialog.displayDialog(context,"Thiruvananthapuram District is the southernmost district in the Indian state of Kerala. The district was created in 1949, with its headquarters in the city of Thiruvananthapuram, which is also Kerala's capital. The present district was created in 1956 by separating the four southernmost Taluks of the erstwhile district to form Kanyakumari district. The district is home to more than 9% of total population of the state.");
                }if (position==6){
                    MyCustomDialog.displayDialog(context,"\n" +
                            "Munroe Island or Mundrothuruthu is an inland island group located at the confluence of Ashtamudi Lake and the Kallada River, in Kollam district, Kerala, South India. It is a group of eight small islets comprising a total area of about 13.4 sqkm. The island, accessible by road, rail and inland water navigation, is about 25 kilometres from Kollam by road, 38 kilometres north from Paravur, 12 kilometres west from Kundara and about 25 kilometres from Karunagapally. As of the 2011 Indian census, the administrative village of Mundrothuruth has a total population of 9599, consisting of 4636 males and 4963 females.");
                }if (position==7){
                    MyCustomDialog.displayDialog(context,"Nilambur is a major town, a municipality and a Taluk in the Malappuram district of the Indian state of Kerala. It is located close to the Nilgiris range of the Western Ghats on the banks of the Chaliyar River. This place is also often called as Teak Town by many because of the abundance of Nilambur teaks in this area; Which is a variety of a large, deciduous tree that occurs in mixed hardwood forests. Unlike many Municipalities of India; Nilambur is covered with large amounts of vegetation making it close to nature and hence make it very scenic and inspiring.");
                }
            }
        });
        holder.btnhotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position==0){
                    Intent i=new Intent(context,AlleppeyhotelActivity2.class);
                    context.startActivity(i);
                }if (position==2){
                    Intent i=new Intent(context,AshtamudiActivity.class);
                    context.startActivity(i);
                }if (position==3){
                    Intent i=new Intent(context,PoovarActivity.class);
                    context.startActivity(i);
                }if (position==4){
                    Intent i=new Intent(context,MararihotelActivity.class);
                    context.startActivity(i);
                }if (position==5){
                    Intent i=new Intent(context,ThiruvananthapuramhotelActivity.class);
                    context.startActivity(i);
                }if (position==6){
                    Intent i=new Intent(context,MunroehotelActivity.class);
                    context.startActivity(i);
                }if (position==7){
                    Intent i=new Intent(context,NilamburhotelActivity.class);
                    context.startActivity(i);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return keralas.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);
        }
    }
}
