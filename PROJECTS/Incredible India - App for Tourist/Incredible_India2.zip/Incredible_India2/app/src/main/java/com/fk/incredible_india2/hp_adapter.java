package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class hp_adapter extends RecyclerView.Adapter<hp_adapter.Myclass> {
    Context context;
    ArrayList<HP> hps;

    public hp_adapter(Context context, ArrayList<HP> hps) {
        this.context = context;
        this.hps = hps;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
        HP h=hps.get(position);
        holder.imgg.setImageResource(h.getBg());
        holder.txtg.setText(h.getTitle());
        holder.btninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position==0){
                    MyCustomDialog.displayDialog(context,"Kasol is a hamlet in the district Kullu of the Indian state of Himachal Pradesh. It is situated in Parvati Valley, on the banks of the Parvati River, on the way between Bhuntar and Manikaran. It is located 30 km from Bhuntar and 3.5 km from Manikaran. Kasol is the Himalayan hotspot for backpackers. and acts as a base for nearby treks to Malana and Kheerganga. It is called Mini Israel of India due to a high percentage of Israeli tourists here.");
                }if (position==1){
                    MyCustomDialog.displayDialog(context,"Kasauli is a little small cantonment town in Solan district in Himachal Pradesh. The town is the home of the Kasauli Brewery, which is the highest brewery and distillery in the world. The cantonment was established in 1842 by the British colonial rulers as a hill station. Located 77 km from Shimla, 65 km from Chandigarh and 50 km from Panchkula at a height of 1800 meters, it still retains the old world charms and is a throwback to the past. Kasauli is a quaint little town that seems to exist in a time wrap of an era that reminds one of the 19th century. Its colonial ambience is reinforced by cobbled paths, quaint shops, gabled houses with charming facades and scores of neat little gardens and orchards. Mixed forests of chir-pine, Himalayan oak and huge horse chestnuts surround Kasauli. Its narrow road slither up and down the hillsides and offer some magnificent vistas");
                }if (position==2){
                    MyCustomDialog.displayDialog(context,"Shimla, also known as Simla, is the capital and the largest city of the Indian state of Himachal Pradesh. In 1864, Shimla was declared as the summer capital of British India. After independence, the city became the capital of Punjab and was later made the capital of Himachal Pradesh. It is the principal commercial, cultural and educational centre of the state. It was the capital city of British Burma from 1942 to 1945.");
                }if (position==3){
                    MyCustomDialog.displayDialog(context,"Dharamshala is the district headquarters of Kangra district of Himachal Pradesh, India. Kangra District was part of the British province of Punjab. The administrative headquarters of the district were initially at Kangra, but were moved to Dharamshala in 1855. Dharamshala is 18 km from Kangra.");
                }if (position==4){
                    MyCustomDialog.displayDialog(context,"Chitkul is a village in Kinnaur district of Himachal Pradesh. During winters, the place mostly remains covered with the snow and the inhabitants move to lower regions of Himachal. According to a recent study by Centre of Atmospheric Sciences at IIT Delhi, Chitkul has the cleanest air in India.");
                }if (position==5){
                    MyCustomDialog.displayDialog(context,"Bir is a rural village located in the west of Joginder Nagar Valley in the state of Himachal Pradesh in northern India. It is also the location of the Bir Tibetan Colony, founded in the early 1960's as a settlement for Tibetan refugees after the 1959 Tibetan uprising.\n" +
                            "\n" +
                            "Bir is noted for several Tibetan Buddhist monasteries and supportive centers of the Nyingma school, the Karma Kagyu school, and the Sakya school, located either in the town of Bir or nearby. A large stupa is also located in Bir. Ecotourism, spiritual studies, and meditation draws visitors.");
                }
            }
        });
        holder.btnhotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position==0){
                    Intent i=new Intent(context,KasolHotelActivity.class);
                    context.startActivity(i);
                }if (position==1){
                    Intent i=new Intent(context,KasauliHotelActivity.class);
                    context.startActivity(i);
                }if (position==2){
                    Intent i=new Intent(context,ShimlaHotelActivity.class);
                    context.startActivity(i);
                }if (position==3){
                    Intent i=new Intent(context,DharamshalaHotelActivity.class);
                    context.startActivity(i);
                }if (position==4){
                    Intent i=new Intent(context,ChitkulHotelActivity.class);
                    context.startActivity(i);
                }if (position==5){
                    Intent i=new Intent(context,BirBillinghotelActivity.class);
                    context.startActivity(i);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return hps.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);
        }
    }
}
