package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.Myclass> {
    Context context;
    ArrayList<Cities> cities;

    public MyAdapter(@NonNull Context context, ArrayList<Cities> cities) {
        this.context = context;
        this.cities = cities;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.city_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
        Cities c=cities.get(position);
        holder.img.setImageResource(c.getBg());
        holder.txt.setText(c.getTitle());

        holder.img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.txt.getText().equals("Gujarat")){
                    Intent i=new Intent(context,GujaratActivity.class);
                    context.startActivity(i);
                }else if (holder.txt.getText().equals("Rajasthan")){
                    Intent i=new Intent(context,RajasthanActivity.class);
                    context.startActivity(i);
                }else if (holder.txt.getText().equals("Goa")){
                    Intent i=new Intent(context, GoaActivity.class);
                    context.startActivity(i);
                }else if (holder.txt.getText().equals("Himachal Pradesh")){
                    Intent i=new Intent(context,HPActivity.class);
                    context.startActivity(i);
                }else if (holder.txt.getText().equals("Maharashtra")){
                    Intent i=new Intent(context,MHActivity.class);
                    context.startActivity(i);
                }else if (holder.txt.getText().equals("Jammu Kashmir")){
                    Intent i=new Intent(context,JKActivity.class);
                    context.startActivity(i);
                }else if (holder.txt.getText().equals("Kerala")){
                    Intent i=new Intent(context,KeralaActivity.class);
                    context.startActivity(i);
                }else
                {
                    Toast.makeText(context, "click on the given list", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return cities.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView img;
        TextView txt;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.img);
            txt=itemView.findViewById(R.id.txt);

        }
    }
}

