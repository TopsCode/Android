package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class mh_adapter extends RecyclerView.Adapter<mh_adapter.Myclass> {
    Context context;
    ArrayList<MH> mhs;

    public mh_adapter(Context context, ArrayList<MH> mhs) {
        this.context = context;
        this.mhs = mhs;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v=LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
MH mh=mhs.get(position);
holder.imgg.setImageResource(mh.getBg());
holder.txtg.setText(mh.getTitle());
holder.btninfo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            MyCustomDialog.displayDialog(context,"Mumbai is the capital city of the Indian state of Maharashtra. According to the United Nations, as of 2018, Mumbai is the second-most populous city in the country after Delhi and the seventh-most populous city in the world with a population of roughly 20 million. As per Indian government population census of 2011, Mumbai was the most populous city in India with an estimated city proper population of 12.5 million living under Municipal Corporation of Greater Mumbai. Mumbai is the centre of the Mumbai Metropolitan Region, the sixth most populous metropolitan area in the world with a population of over 23 million. Mumbai lies on the Konkan coast on the west coast of India and has a deep natural harbour. In 2008, Mumbai was named an alpha world city. It has the highest number of millionaires and billionaires among all cities in India. Mumbai is home to three UNESCO World Heritage Sites: the Elephanta Caves, Chhatrapati Shivaji Maharaj Terminus, and the city's distinctive ensemble of Victorian and Art Deco buildings.");
        }if (position==1){
            MyCustomDialog.displayDialog(context,"Kolhapur, is a city in the Indian state of Maharashtra. It is the district headquarters of Kolhapur district. Prior to Indian Independence, Kolhapur was a nineteen gun salute, princely state known as Kolhapur State and was ruled by the Bhosale Chhatrapati of the Maratha Empire.");
        }if (position==2){
            MyCustomDialog.displayDialog(context,"Alibag is a coastal town and a municipal council in Raigad District of Maharashtra, India. It is the headquarters of the Raigad district and is south of the city of Mumbai. Alibag is part of Mumbai Metropolitan Region and is situated at a distance of about 96km from Mumbai and 143km from Pune.");
        }if (position==3){
            MyCustomDialog.displayDialog(context,"Mahabaleshwar is a small town and a municipal council in Satara district in the Indian state of Maharashtra.It is a place of pilgrimage for Hindus because the Krishna river has its origins here. The British colonial rulers developed the town as a hill station, and served as the summer capital of Bombay Presidency during the British Raj.");
        }if (position==4){
            MyCustomDialog.displayDialog(context,"Solapur is a city located in the south-western region of the Indian state of Maharashtra, close to its border with Karnataka. Solapur is located on major highway, rail routes between Mumbai, Pune, Bangalore and Hyderabad, with a branch line to the cities of Bijapur and Gadag in the neighbouring state of Karnataka. Solapur international Airport is under construction. It is classified as A1 Tier and B-1 class city by House Rent Allowance classification by the Government of India. It is the 11th biggest city in Maharashtra and the 49th most populous city in India and 43rd largest urban agglomeration.");
        }if (position==5){
            MyCustomDialog.displayDialog(context,"Matheran is a hill station and a municipal council in Karjat Tahsil in the Raigad district in the Indian state of Maharashtra. Matheran is part of the Mumbai Metropolitan Region. Matheran is one of the smallest hill stations in India. It is located on the Western Ghats range at an elevation of around 800 m above sea level. It is about 90 km from Mumbai, and 120 km from Pune. Matheran's proximity to many metropolitan cities makes it a weekend getaway for urban residents. Matheran, which means \"forest on the forehead\" is an eco-sensitive region, declared by the Ministry of Environment, Forest and Climate Change, Government of India. It is Asia's only automobile-free hill station.");
        }if (position==6){
            MyCustomDialog.displayDialog(context,"Aurangabad is 2200 year old city which was known as Rajtadak, Kirkee Fatehnager and finally renamed after Aurangzeb and came to be known as Aurangabad. Aurangabd was founded in 1653 by the Mughal emperor, Aurangzeb who established his capital here once he became the Viceroy of Deccan. It is surrounded by Lakenvasa Hills on the North and Satasa Hills on the South. Today, it is an integral part of the region that is home to Buddhist, Hindu and Islamic monuments. The charm and glory of its long past has not been lost till today and its heritage is also very rich and varied. This city still evokes the feeling of royal splendour, which was once, a way of life. Its past finds a fine expression in its fort, the fort wall and other relics spread across the city. The city is the district headquarters, which offers visitors all the modem comforts and amenities. The present Government names this city as ‘Sambhajinagar’. Today, Aurangabad is known for some of the finest colleges and universities in Maharashtra. It is the fastest growing industrial town in India. Aurangabad experiences extreme climate; hot summers and cold winters. The best time to visit this place is from October to March. Marathi, Hindi, Urdu and English are the various languages which are spoken in Aurangabad.");
        }
    }
});
holder.btnhotel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            Intent i=new Intent(context,MumbaiHotelActivity.class);
            context.startActivity(i);
        }if (position==1){
            Intent i=new Intent(context,KolhapurHotelActivity.class);
            context.startActivity(i);
        }if (position==2){
            Intent i=new Intent(context,AlibaugHotelActivity.class);
            context.startActivity(i);
        }if (position==3){
            Intent i=new Intent(context,MahabaleshwarHotelActivity.class);
            context.startActivity(i);
        }if (position==4){
            Intent i=new Intent(context,SolapurHotelActivity.class);
            context.startActivity(i);
        }if (position==5){
            Intent i=new Intent(context,MatheranHotelActivity.class);
            context.startActivity(i);
        }if (position==6){
            Intent i=new Intent(context,AurangabadHotelActivity.class);
            context.startActivity(i);
        }
    }
});
    }

    @Override
    public int getItemCount() {
        return mhs.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);

        }
    }
}
