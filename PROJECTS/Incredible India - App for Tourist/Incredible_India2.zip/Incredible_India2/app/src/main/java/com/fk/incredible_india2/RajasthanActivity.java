package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class RajasthanActivity extends AppCompatActivity {

    Toolbar mytoolbar;
    TabLayout tab_layoutrj;
    ViewPager view_pagerrj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rajasthan);
        setTitle("Rajasthan");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layoutrj=findViewById(R.id.tab_layoutrj);
        view_pagerrj=findViewById(R.id.view_pagerrj);

        viewpager_adapter viewpagerAdapter=new viewpager_adapter(getSupportFragmentManager());
        viewpagerAdapter.addfragments(new RJCityFragment(),"City");
        viewpagerAdapter.addfragments(new RJHistoryFragment(),"History");
        viewpagerAdapter.addfragments(new RJMapFragment(),"Map");

        view_pagerrj.setAdapter(viewpagerAdapter);
        tab_layoutrj.setupWithViewPager(view_pagerrj);
    }
}