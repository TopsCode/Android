package com.fk.incredible_india2;

public class MH {
    int bg;
    String title;

    public int getBg() {
        return bg;
    }

    public void setBg(int bg) {
        this.bg = bg;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public MH(int bg, String title) {
        this.bg = bg;
        this.title = title;
    }
}
