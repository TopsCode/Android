package com.fk.incredible_india2;

public class HP {
    int bg;
    String title;

    public int getBg() {
        return bg;
    }

    public void setBg(int bg) {
        this.bg = bg;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public HP(int bg, String title) {
        this.bg = bg;
        this.title = title;
    }
}
