package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class BikanerHotelActivity extends AppCompatActivity {

    int im[]={R.mipmap.narendra,R.mipmap.laxmi};
    String title[]={"Narendra Bhawan","The Laxmi Niwas Palace"};
    String add[]={"Karni Nagar, Gandhi Nagar, 334001 Bikaner, India","Dr. Karni Singhji Road, 334001 Bikaner, India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bikaner_hotel);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(BikanerHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(BikanerHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}