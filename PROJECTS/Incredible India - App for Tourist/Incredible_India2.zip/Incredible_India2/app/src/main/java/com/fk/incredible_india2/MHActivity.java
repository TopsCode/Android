package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MHActivity extends AppCompatActivity {

    Toolbar mytoolbar;
    TabLayout tab_layout_mh;
    ViewPager view_pager_mh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_h);
        setTitle("Maharashtra");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layout_mh=findViewById(R.id.tab_layoutmh);
        view_pager_mh=findViewById(R.id.view_pager_mh);

        viewpager_adapter viewpager_adapter=new viewpager_adapter(getSupportFragmentManager());
        viewpager_adapter.addfragments(new mhCityFragment(),"City");
        viewpager_adapter.addfragments(new mhHistoryFragment(),"History");
        viewpager_adapter.addfragments(new mhMapFragment(),"Map");

        view_pager_mh.setAdapter(viewpager_adapter);
        tab_layout_mh.setupWithViewPager(view_pager_mh);
    }
}