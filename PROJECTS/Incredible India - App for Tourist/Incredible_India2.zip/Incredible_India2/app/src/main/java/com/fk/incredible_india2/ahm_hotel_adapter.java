package com.fk.incredible_india2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ahm_hotel_adapter extends RecyclerView.Adapter<ahm_hotel_adapter.Myclass> {
    Context context;
    ArrayList<hotel> hotels;

    public ahm_hotel_adapter(Context context, ArrayList<hotel> hotels) {
        this.context = context;
        this.hotels = hotels;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.hotel,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
        hotel h=hotels.get(position);
        holder.imgh.setImageResource(h.getBg());
        holder.txttitle.setText(h.getTitle());
        holder.txtadd.setText(h.getAdd());
    }

    @Override
    public int getItemCount() {
        return hotels.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgh;
        TextView txttitle,txtadd;

        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgh=itemView.findViewById(R.id.imgh);
            txtadd=itemView.findViewById(R.id.txtadd);
            txttitle=itemView.findViewById(R.id.txttitle);

        }
    }
}

