package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class KeralaActivity extends AppCompatActivity {
Toolbar mytoolbar;
TabLayout tab_layout_k;
ViewPager view_pager_k;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kerala);
        setTitle("Kerala");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layout_k=findViewById(R.id.tab_layout_k);
        view_pager_k=findViewById(R.id.view_pager_k);

        viewpager_adapter viewpagerAdapter=new viewpager_adapter(getSupportFragmentManager());
        viewpagerAdapter.addfragments(new kCityFragment(),"City");
        viewpagerAdapter.addfragments(new kHistoryFragment(),"History");
        viewpagerAdapter.addfragments(new kMapFragment(),"Map");

        view_pager_k.setAdapter(viewpagerAdapter);
        tab_layout_k.setupWithViewPager(view_pager_k);
    }
}