package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class JaipurHotelActivity extends AppCompatActivity {

    int im[]={R.mipmap.perl,R.mipmap.samode};
    String title[]={"Hotel Pearl Palace","Samode Haveli"};
    String add[]={" 51 Hathroi Forth Hari Kishan Somani Marg, 302001 Jaipur, India","Gangapole, 302002 Jaipur, India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jaipur_hotel);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(JaipurHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(JaipurHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}