package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class AlleppeyhotelActivity2 extends AppCompatActivity {

    int im[]={R.mipmap.palmyra};
    String title[]={"Treebo Tryst Palmyra Milford,Alleppey"};
    String add[]={"Old Medical College Junction, Allappuzha , 688011 Alleppey, India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alleppeyhotel2);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(AlleppeyhotelActivity2.this);
        recv.setLayoutManager(layoutManager);
        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(AlleppeyhotelActivity2.this,al);
        recv.setAdapter(adapter);
    }
}