package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class JKActivity extends AppCompatActivity {
Toolbar mytoolbar;
TabLayout tab_layout_jk;
ViewPager view_pager_jk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_j_k);
        setTitle("J-K");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layout_jk=findViewById(R.id.tab_layout_jk);
        view_pager_jk=findViewById(R.id.view_pager_jk);

        viewpager_adapter viewpagerAdapter=new viewpager_adapter(getSupportFragmentManager());
        viewpagerAdapter.addfragments(new jkCityFragment(),"City");
        viewpagerAdapter.addfragments(new jkHistoryFragment(),"History");
        viewpagerAdapter.addfragments(new jkMapFragment(),"Map");

        view_pager_jk.setAdapter(viewpagerAdapter);
        tab_layout_jk.setupWithViewPager(view_pager_jk);

    }
}