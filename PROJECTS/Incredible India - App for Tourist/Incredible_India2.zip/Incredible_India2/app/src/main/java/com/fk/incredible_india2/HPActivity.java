package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class HPActivity extends AppCompatActivity {

    Toolbar mytoolbar;
    TabLayout tab_layout_hp;
    ViewPager view_pager_hp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h_p);
        setTitle("Himachal Pradesh");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layout_hp=findViewById(R.id.tab_layout_hp);
        view_pager_hp=findViewById(R.id.view_pager_hp);

        viewpager_adapter viewpager_adapter=new viewpager_adapter(getSupportFragmentManager());
        viewpager_adapter.addfragments(new hpCityFragment(),"City");
        viewpager_adapter.addfragments(new hpHistoryFragment(),"History");
        viewpager_adapter.addfragments(new hpMapFragment(),"Map");

        view_pager_hp.setAdapter(viewpager_adapter);
        tab_layout_hp.setupWithViewPager(view_pager_hp);

    }
}