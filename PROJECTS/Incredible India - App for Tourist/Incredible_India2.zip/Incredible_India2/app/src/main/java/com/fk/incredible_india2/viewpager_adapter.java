package com.fk.incredible_india2;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class viewpager_adapter extends FragmentPagerAdapter {
    ArrayList<Fragment> fragments;
    ArrayList<String> title;

    public viewpager_adapter(@NonNull FragmentManager fm) {
        super(fm);
        fragments=new ArrayList<>();
        title=new ArrayList<>();
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    public void addfragments(Fragment fragment,String Title){
        fragments.add(fragment);
        title.add(Title);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return title.get(position);
    }
}

