package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class rj_adapter extends RecyclerView.Adapter<rj_adapter.Myclass> {
    Context context;
    ArrayList<rajasthan> rajasthans;

    public rj_adapter(Context context, ArrayList<rajasthan> rajasthans) {
        this.context = context;
        this.rajasthans = rajasthans;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
rajasthan rj=rajasthans.get(position);
holder.imgg.setImageResource(rj.getBg());
holder.txtg.setText(rj.getTitle());

holder.btninfo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            MyCustomDialog.displayDialog(context,"Jaipur is also known as the Pink City, due to the dominant color scheme of its buildings. It is located 268 km (167 miles) from the national capital New Delhi . Jaipur was founded in 1727 by the Rajput ruler Jai Singh II, the ruler of Amer, after whom the city is named.");
        }else if (position==1) {
            MyCustomDialog.displayDialog(context, "Udaipur, also known as the \"City of Lakes\" is a city in the state of Rajasthan in India. It is the historic capital of the kingdom of Mewar in the former Rajputana Agency. It was founded in 1558 by Udai Singh II of the Sisodia clan of Rajput, when he shifted his capital from the city of Chittorgarh to Udaipur after Chittorgarh was besieged by Akbar. It remained as the capital city till 1818 when it became a British princely state, and thereafter the Mewar province became a part of Rajasthan when India gained independence in 1947.");
        }else if (position==2) {
            MyCustomDialog.displayDialog(context, "Jodhpur is the second-largest city in the Indian state of Rajasthan and officially the second metropolitan city of the state. It was formerly the seat of the princely state of Jodhpur State. Jodhpur was historically the capital of the Kingdom of Marwar, which is now part of Rajasthan. Jodhpur is a popular tourist destination, featuring many palaces, forts, and temples, set in the stark landscape of the Thar Desert. It is popularly known as the \"Blue City\" among people of Rajasthan and all over India.");
        }else if (position==3) {
            MyCustomDialog.displayDialog(context, "Ajmer is one of the major and oldest cities in the Indian state of Rajasthan and the centre of the eponymous Ajmer District. It is located at the centre of Rajasthan, and is home to the Ajmer Sharif shrine.");
        }else if (position==4) {
            MyCustomDialog.displayDialog(context, "Chittorgarh is a major city in Rajasthan state of western India. It lies on the Berach River, a tributary of the Banas, and is the administrative headquarters of Chittorgarh District and a former capital of the Sisodia Rajput dynasty of Mewar. The city of Chittaurgarh is located on the banks of river Gambhiri and Berach.");
        }else if (position==5) {
            MyCustomDialog.displayDialog(context, "Bikaner is a city in the northwest of the state of Rajasthan, India. It is located 330 kilometres northwest of the state capital, Jaipur. Bikaner city is the administrative headquarters of Bikaner District and Bikaner division.");
        }else if (position==6) {
            MyCustomDialog.displayDialog(context, "Jaisalmer, nicknamed \"The Golden city\", is a city in the Indian state of Rajasthan, located 575 kilometres west of the state capital Jaipur. The town stands on a ridge of yellowish sandstone and is crowned by the ancient Jaisalmer Fort. This fort contains a royal palace and several ornate Jain temples. Many of the houses and temples of both the fort and of the town below are built of finely sculptured sandstone. The town lies in the heart of the Thar Desert and has a population, including the residents of the fort, of about 78,000. It is the administrative headquarters of Jaisalmer District. Jaisalmer was once the capital of Jaisalmer State.");
        }

    }
});
holder.btnhotel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            Intent i=new Intent(context,JaipurHotelActivity.class);
            context.startActivity(i);
        }if (position==1){
            Intent i=new Intent(context,UdaipurHotelActivity.class);
            context.startActivity(i);
        }if (position==2){
            Intent i=new Intent(context,JodhpurHotelActivity.class);
            context.startActivity(i);
        }if (position==3){
            Intent i=new Intent(context,AjmerHotelActivity.class);
            context.startActivity(i);
        }if (position==4){
            Intent i=new Intent(context,ChittorgarhHotelActivity.class);
            context.startActivity(i);
        }if (position==5){
            Intent i=new Intent(context,BikanerHotelActivity.class);
            context.startActivity(i);
        }if (position==6){
            Intent i=new Intent(context,JaisalmerHotelActivity.class);
            context.startActivity(i);
        }
    }
});
    }

    @Override
    public int getItemCount() {
        return rajasthans.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);
        }
    }
}
