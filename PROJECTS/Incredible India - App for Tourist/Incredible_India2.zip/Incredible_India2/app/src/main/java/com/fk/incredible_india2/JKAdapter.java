package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class JKAdapter extends RecyclerView.Adapter<JKAdapter.Myclass> {
    Context context;
    ArrayList<JK> jks;

    public JKAdapter(Context context, ArrayList<JK> jks) {
        this.context = context;
        this.jks = jks;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
JK j=jks.get(position);
holder.imgg.setImageResource(j.getBg());
holder.txtg.setText(j.getTitle());
holder.btninfo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            MyCustomDialog.displayDialog(context,"Srinagar is the largest city and the summer capital of the Indian union territory of Jammu and Kashmir. It lies in the Kashmir Valley on the banks of the Jhelum River, a tributary of the Indus, and Dal and Anchar lakes. The city is known for its natural environment, gardens, waterfronts and houseboats. It is also known for traditional Kashmiri handicrafts like Kashmir shawls and also dried fruits. It is the northernmost city of India with over one million people.");
        }if (position==1){
            MyCustomDialog.displayDialog(context,"Gulmarg is a town, a hill station, a popular skiing destination and a notified area committee in the Baramulla district of the Indian union territory of Jammu and Kashmir. The town is situated in the Pir Panjal Range in the western Himalayas.");
        }if (position==2){
            MyCustomDialog.displayDialog(context,"Jammu is the winter capital of the Indian union territory of Jammu and Kashmir. It is the headquarters and the largest city in Jammu district of the union territory. Lying on the banks of the river Tawi, the city of Jammu, with an area of 26.64 km (10.29 sq mi), is surrounded by the Himalayas in the north and the northern-plains in the south.");
        }if (position==3){
            MyCustomDialog.displayDialog(context,"Pahalgam is a town and a notified area committee in Anantnag district of the Indian union territory of Jammu and Kashmir. It is a popular tourist destination and hill station. Its lush green meadows and pristine waters attract thousands of tourists from all over the world each year. It is located 45 kilometres from Anantnag on the banks of Lidder River at an altitude of 7,200 feet. Pahalgam is the headquarters of one of the five tehsils of Anantnag district. Pahalgam is associated with the annual Amarnath Yatra. Chandanwari, located 16 kilometres from Pahalgam is the starting point of the yatra that takes place every year in the months of July–August.");
        }if (position==4){
            MyCustomDialog.displayDialog(context,"Leh is the joint capital and largest town of the union territory of Ladakh in India. Leh, located in the Leh district, was also the historical capital of the Himalayan Kingdom of Ladakh, the seat of which was in the Leh Palace, the former residence of the royal family of Ladakh, built in the same style and about the same time as the Potala Palace in Tibet. Leh is at an altitude of 3,524 metres, and is connected via National Highway 1 to Srinagar in the southwest and to Manali in the south via the Leh-Manali Highway.");
        }
    }
});
holder.btnhotel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            Intent i=new Intent(context,SrinagarHotelActivity.class);
            context.startActivity(i);
        }if (position==1){
            Intent i=new Intent(context,GulmargHotelActivity.class);
            context.startActivity(i);
        }if (position==2){
            Intent i=new Intent(context,JammuHotelActivity.class);
            context.startActivity(i);
        }if (position==3){
            Intent i=new Intent(context,PahalgamHotelActivity.class);
            context.startActivity(i);
        }if (position==4){
            Intent i=new Intent(context,LehHotelActivity.class);
            context.startActivity(i);
        }
    }
});
    }

    @Override
    public int getItemCount() {
        return jks.size();
    }

    class Myclass extends RecyclerView.ViewHolder {

        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);
        }
    }
}
