package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class LehHotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.dragon};
    String title[]={"The Grand Dragon"};
    String add[]={"Old Road Sheynam, 194101 Leh, India "};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leh_hotel);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(LehHotelActivity.this);
        recv.setLayoutManager(layoutManager);
        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(LehHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}