package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class KasauliHotelActivity extends AppCompatActivity {

    int im[]={R.mipmap.pines};
    String title[]={"7 Pines"};
    String add[]={"7 Pines District- Solan, Kasauli, Himachal Pradesh, 173225 Kasauli, India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kasauli);

        recv=findViewById(R.id.recv);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(KasauliHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(KasauliHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}