package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class VadodaraHotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.grandmercure,R.mipmap.effotel,R.mipmap.fern,R.mipmap.fortune};
    String title[]={"Grand Mercure Surya Palace","Effotel By Sayaji Vadodara","The Fern An Ecotel Hotel","Fortune Inn Promenade"};
    String add[]={"Jetalpur Rd Opp. Parsi Agyari, Sayajigunj, Vadodara 390020 India","Kala Ghoda Circle Sayajigunj, Vadodara 390005 India","Dinesh Mill Road, Vadodara 390020 India","Near Akota - Mujmahuda Rd, Pratham Avenue, Vadodara 390020 India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vadodara_hotel);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(VadodaraHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++) {
            hotel ho = new hotel(im[i], title[i], add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(VadodaraHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}