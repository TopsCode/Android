package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class ShimlaHotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.clarks};
    String title[]={"Clarks Collection The Retreat"};
    String add[]={"Village Patangli PO Mashobra, Tehsil and Distt. Shimla, 171007 Shimla, India "};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shimla_hotel);

        recv=findViewById(R.id.recv);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(ShimlaHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(ShimlaHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}