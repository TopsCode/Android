package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class GujaratActivity extends AppCompatActivity {

    TabLayout tab_layout;
    Toolbar mytoolbar;
    ViewPager view_pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gujarat);
        setTitle("Gujarat");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layout=findViewById(R.id.tab_layout);
        view_pager=findViewById(R.id.view_pager);

        viewpager_adapter viewpagerAdapter=new viewpager_adapter(getSupportFragmentManager());
        viewpagerAdapter.addfragments(new CityFragment(),"City");
        viewpagerAdapter.addfragments(new HistoryFragment(),"History");
        viewpagerAdapter.addfragments(new gujaratMapFragment(),"Map");

        view_pager.setAdapter(viewpagerAdapter);
        tab_layout.setupWithViewPager(view_pager);
    }
}