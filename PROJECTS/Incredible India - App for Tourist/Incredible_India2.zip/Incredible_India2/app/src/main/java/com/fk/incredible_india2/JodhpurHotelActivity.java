package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class JodhpurHotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.ratan,R.mipmap.kankariya};
    String title[]={"Ratan Vilas","Kankariya Heritage"};
    String add[]={"Near Bhaskar Circle, Loco shed Road , Ratanada, Ratanada, 342001 Jodhpur, India","Opp Arya Marudhar Vyayam Sala- Gulab Sagar Jodhpur, 342001 Jodhpur, India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jodhpur);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(JodhpurHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(JodhpurHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}