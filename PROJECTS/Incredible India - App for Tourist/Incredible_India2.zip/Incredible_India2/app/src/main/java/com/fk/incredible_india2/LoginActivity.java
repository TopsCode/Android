package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    EditText etemail,etpass;
    TextView tvnewuser,tvguest;
    Button btnenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etemail=findViewById(R.id.etemail);
        etpass=findViewById(R.id.etpass);
        btnenter=findViewById(R.id.btnenter);

        tvnewuser=findViewById(R.id.tvnewuser);
        tvguest=findViewById(R.id.tvguest);

        btnenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=etemail.getText().toString();
                String password=etpass.getText().toString();

                if (TextUtils.isEmpty(email)){
                    etemail.setError("this field is mendatory");
                }else if (TextUtils.isEmpty(password)){
                    etpass.setError("this field is mendatory");
                }else{
                    Intent intent=new Intent(LoginActivity.this,MainActivity.class);
                    startActivity(intent);
                    etemail.setText("");
                    etpass.setText("");
                }
            }
        });
        tvnewuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(LoginActivity.this,newuserActivity.class);
                startActivity(i);
            }
        });
        tvguest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(LoginActivity.this,guestActivity.class);
                startActivity(i);
            }
        });


    }
}