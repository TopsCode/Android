package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class GoaActivity extends AppCompatActivity {
    Toolbar mytoolbar;
    TabLayout tab_layoutgoa;
    ViewPager view_pagergoa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goa);
        setTitle("Goa");

        mytoolbar=findViewById(R.id.mytoolbar);
        setSupportActionBar(mytoolbar);

        tab_layoutgoa=findViewById(R.id.tab_layoutgoa);
        view_pagergoa=findViewById(R.id.view_pagergoa);

        viewpager_adapter viewpagerAdapter=new viewpager_adapter(getSupportFragmentManager());
        viewpagerAdapter.addfragments(new GoaCityFragment(),"City");
        viewpagerAdapter.addfragments(new GoaHistoryFragment(),"History");
        viewpagerAdapter.addfragments(new GoaMapFragment(),"Map");

        view_pagergoa.setAdapter(viewpagerAdapter);
        tab_layoutgoa.setupWithViewPager(view_pagergoa);


    }
}