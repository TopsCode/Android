package com.fk.incredible_india2;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyCustomDialog {
    public static void displayDialog(Context context, String info){
        Dialog d=new Dialog(context);
        d.setContentView(R.layout.info_ahm_dialog);

        TextView infoo;
        Button btncl;

        infoo=d.findViewById(R.id.infoo);
        infoo.setText(info);

        btncl=d.findViewById(R.id.btncl);
        btncl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        d.show();

    }
}
