package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MunroehotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.hampton};
    String title[]={"Hampton Inn & Suites Monroe"};
    String add[]={"5100 Frontage Rd, Monroe, LA 71202-4010"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_munroehotel);

        recv=findViewById(R.id.recv);

        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(MunroehotelActivity.this);
        recv.setLayoutManager(layoutManager);
        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(MunroehotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}