package com.fk.incredible_india2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    int im[]={R.mipmap.gujarat,R.mipmap.rajasthann,R.mipmap.goa,R.mipmap.hp,R.mipmap.maharashtra,R.mipmap.jk,R.mipmap.kerala};
    String title[] ={"Gujarat","Rajasthan","Goa","Himachal Pradesh","Maharashtra","Jammu Kashmir","Kerala"};

    ArrayList<Cities> al=new ArrayList<>();



    RecyclerView rev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar_layout);

        rev=findViewById(R.id.rev);



        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(MainActivity.this);
        rev.setLayoutManager(layoutManager);
        al.clear();
        for (int i=0;i<im.length;i++){
            Cities a=new Cities(im[i],title[i]);
            al.add(a);
        }
        MyAdapter adapter=new MyAdapter(MainActivity.this,al);
        rev.setAdapter(adapter);
    }

}