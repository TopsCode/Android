package com.fk.incredible_india2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class goa_adapter extends RecyclerView.Adapter<goa_adapter.Myclass> {
    Context context;
    ArrayList<goa> goas;

    public goa_adapter(Context context, ArrayList<goa> goas) {
        this.context = context;
        this.goas = goas;
    }

    @NonNull
    @Override
    public Myclass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.gujarat_data,parent,false);
        return new Myclass(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myclass holder, int position) {
goa g=goas.get(position);
holder.imgg.setImageResource(g.getBg());
holder.txtg.setText(g.getTitle());
holder.btninfo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            MyCustomDialog.displayDialog(context,"Mormugao Fort is an ancient but well-preserved fortification and a symbol of the Portuguese rule over Goa. Covering a circumference of around 10 km, the fort lies around 33 km from the Panjim Kadamba Bus Stand, and just 4 km from Vasco Da Gama Railway Station. It is located south of the Mormugao port in South Goa. The fort was built in 1624 to protect the port and its waters. As such, it was one of the toughest fortifications of the Portuguese, jutting out into the sea to give a commanding view of the hostile waters beyond the harbor. Over the course of its life, the fort would be attacked several times by the Marathas, until the Portuguese decided to focus its colonization efforts on Old Goa.");
        }if (position==1){
            MyCustomDialog.displayDialog(context,"Panaji is the capital of the Indian state of Goa and the headquarters of North Goa district. It lies on the banks of the Mandovi River estuary in the Tiswadi sub-district. With a population of 114,759 in the metropolitan area, Panaji is Goa's largest urban agglomeration, ahead of Margao and Vasco da Gama.");
        }if (position==2){
            MyCustomDialog.displayDialog(context,"Madgaon is the commercial capital of the Indian state of Goa. It stands on banks of the Sal river and is the administrative headquarters of Salcete sub-district and South Goa district. It is Goa's second largest city by population after Vasco.");
        }
    }
});
holder.btnhotel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (position==0){
            Intent i=new Intent(context,MormugaoHotelActivity.class);
            context.startActivity(i);
        }if (position==1){
            Intent i=new Intent(context,PanajiHotelActivity.class);
            context.startActivity(i);
        }if (position==2){
            Intent i=new Intent(context,MargaoHotelActivity.class);
            context.startActivity(i);
        }
    }
});
    }

    @Override
    public int getItemCount() {
        return goas.size();
    }

    class Myclass extends RecyclerView.ViewHolder {
        ImageView imgg;
        TextView txtg;
        Button btninfo,btnhotel,btnmap;
        public Myclass(@NonNull View itemView) {
            super(itemView);
            imgg=itemView.findViewById(R.id.imgg);
            txtg=itemView.findViewById(R.id.txtg);
            btninfo=itemView.findViewById(R.id.btninfo);
            btnhotel=itemView.findViewById(R.id.btnhotel);
            btnmap=itemView.findViewById(R.id.btnmap);
        }
    }
}
