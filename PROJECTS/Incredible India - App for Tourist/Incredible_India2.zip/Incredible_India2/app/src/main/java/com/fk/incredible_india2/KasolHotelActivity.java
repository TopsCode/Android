package com.fk.incredible_india2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class KasolHotelActivity extends AppCompatActivity {
    int im[]={R.mipmap.hukam};
    String title[]={"Hotel Hukam's Holiday Home"};
    String add[]={"Kasol Road V.P.O KASOL, 175105 Kasol, India"};

    ArrayList<hotel> al=new ArrayList<>();

    RecyclerView recv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kasol_hotel);

        recv=findViewById(R.id.recv);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(KasolHotelActivity.this);
        recv.setLayoutManager(layoutManager);

        for (int i=0;i<im.length;i++){
            hotel ho=new hotel(im[i],title[i],add[i]);
            al.add(ho);
        }
        ahm_hotel_adapter adapter=new ahm_hotel_adapter(KasolHotelActivity.this,al);
        recv.setAdapter(adapter);
    }
}