package com.gujaratit.databasehelper;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.gujaratit.R;
import com.gujaratit.design.MainActivity;
import com.gujaratit.web_service.AppController;


@SuppressLint("NewApi")
public class Update extends Activity {
	Activity mactivity;
	ArrayList<String> strArray;


	private String urlJsonArry;
	private ProgressDialog pDialog;
	private String jsonResponse;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update);
		mactivity = this;
		pDialog = new ProgressDialog(this);
		pDialog.setMessage("Please wait...");
		pDialog.setCancelable(false);
		urlJsonArry = getResources().getString(R.string.data_url);
		
		strArray=new ArrayList<String>();

		makeJsonArrayRequest();

	}

	private void makeJsonArrayRequest() {

		showpDialog();

		JsonArrayRequest req = new JsonArrayRequest(urlJsonArry,
				new Response.Listener<JSONArray>() {
					@Override
					public void onResponse(JSONArray response) {


						try {
							// Parsing json array response
							// loop through each json object
							jsonResponse = "";
							for (int i = 0; i < response.length(); i++) {

								JSONObject person = (JSONObject) response
										.get(i);

								String str = person.getString("Query");
								if(str.length()>10)
									strArray.add(str);
							}

						} catch (JSONException e) {
							e.printStackTrace();

						}
						Update_Database ud=new Update_Database(mactivity);
						ud.Insert_Detail(strArray);

						AppVersion av = new AppVersion(mactivity);
						av.Insert_Detail(MainActivity.onlineVersion);
						hidepDialog();

						Intent i = new Intent(Update.this, MainActivity.class);
						startActivity(i);
						finish();


					}
				}, new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {


				hidepDialog();
			}
		});

		// Adding request to request queue
		AppController.getInstance().addToRequestQueue(req);
	}

	private void showpDialog() {
		if (!pDialog.isShowing())
			pDialog.show();
	}

	private void hidepDialog() {
		if (pDialog.isShowing())
			pDialog.dismiss();
	}




	public class MyExceptionHandler implements
			Thread.UncaughtExceptionHandler {
		private final Context myContext;
		@SuppressWarnings("unused")
		private final Class<?> myActivityClass;

		public MyExceptionHandler(Context context, Class<?> c) {

			myContext = context;
			myActivityClass = c;
		}

		public void uncaughtException(Thread thread, Throwable exception) {

			StringWriter stackTrace = new StringWriter();
			exception.printStackTrace(new PrintWriter(stackTrace));
			System.err.println(stackTrace);// You can use LogCat too
			Intent intent = new Intent(myContext, MainActivity.class);
			String s = stackTrace.toString();
			// you can use this String to know what caused the exception and in
			// which Activity
			intent.putExtra("uncaughtException",
					"Exception is: " + stackTrace.toString());
			intent.putExtra("stacktrace", s);
			// myContext.startActivity(intent);
			// for restarting the Activity

		}
	}

	@Override
	public void onBackPressed() {

	}
}
