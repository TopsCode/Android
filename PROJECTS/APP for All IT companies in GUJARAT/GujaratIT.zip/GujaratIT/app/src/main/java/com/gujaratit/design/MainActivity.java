package com.gujaratit.design;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.gujaratit.R;
import com.gujaratit.constant.Constant;
import com.gujaratit.databasehelper.AppVersion;
import com.gujaratit.databasehelper.DatabaseHelper;
import com.gujaratit.databasehelper.Update;
import com.gujaratit.web_service.AppController;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText edSearchMain;
    String Value;
    DatabaseHelper DBHelper;
    Button btnListByCity, btnListByAlphabet, btnSuggestCompany, btnFavourite, btnDeveloper, btnShareThisApp, btnContactUs;
    Typeface font;
    TextView txtSearchIcon;
    public static int onlineVersion;
   // private String urlJsonObj = "http://api.androidhive.info/volley/person_object.json";

        private String urlJsonObj;
    private ProgressDialog pDialog;
    private String jsonResponse;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        urlJsonObj = getResources().getString(R.string.version_url);


        if (isOnline()) {

            makeJsonObjectRequest();
        }


        btnListByCity = (Button) findViewById(R.id.main_activity_btn_list_by_city);
        btnListByAlphabet = (Button) findViewById(R.id.main_activity_btn_list_by_alphabet);
        btnSuggestCompany = (Button) findViewById(R.id.main_activity_btn_suggest_new_company);
        btnFavourite = (Button) findViewById(R.id.main_activity_btn_favourite);
        btnDeveloper = (Button) findViewById(R.id.main_activity_btn_developer);
        btnShareThisApp = (Button) findViewById(R.id.main_activity_btn_share_app);
        btnContactUs = (Button) findViewById(R.id.main_activity_btn_contact_us);

        DBHelper = new DatabaseHelper(getApplicationContext());
        edSearchMain = (EditText) findViewById(R.id.ed_search_main_activity);
        font = Typeface.createFromAsset(getAssets(), "MaterialIcons-Regular.ttf");
        txtSearchIcon = (TextView) findViewById(R.id.txt_search);
        txtSearchIcon.setTypeface(font);

        txtSearchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Value = String.valueOf(edSearchMain.getText());
                if (Value.length() > 0) {
                    Intent intent = new Intent(MainActivity.this, QuickSearchActivity.class);
                    intent.putExtra("SearchValue", Value);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Enter Some Value", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnListByCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ListByCityActivity.class);
                startActivity(intent);
            }
        });

        btnListByAlphabet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ListByAlphabetActivity.class);
                startActivity(intent);
            }
        });

        btnSuggestCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, SuggestNewCompanyActivity.class);
                startActivity(intent);
            }
        });

        btnFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FavouriteActivity.class);
                startActivity(intent);
            }
        });

        btnDeveloper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DeveloperActivity.class);
                startActivity(intent);
            }
        });

        btnContactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ContactUsActivity.class);
                startActivity(intent);
            }
        });

        btnShareThisApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "Gujarat IT");
                    String strShare = "\nI just Downloaded an App for Gujarat Based IT Industries.You can also download it from Play Store\n\n";
                    strShare = strShare + Constant.AppPlayStoreLink + "\n\n";
                    i.putExtra(Intent.EXTRA_TEXT, strShare);
                    startActivity(Intent.createChooser(i, "Share it via"));
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "No apps to Share", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        Value = String.valueOf(edSearchMain.getText());
        if (String.valueOf(event.getKeyCode()) == String.valueOf(66)) {
            if (event.getAction() == event.ACTION_DOWN) {
                Intent intent = new Intent(MainActivity.this, QuickSearchActivity.class);
                intent.putExtra("SearchValue", Value);
                startActivity(intent);
            }
        }
        return super.dispatchKeyEvent(event);
    }

    protected boolean isOnline() {
        ConnectivityManager connectivity = (ConnectivityManager) this
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }

        }
        return false;
    }


    private void makeJsonObjectRequest() {

        showpDialog();

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                urlJsonObj, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {


                try {
                    // Parsing json object response
                    // response will be a json object
                    onlineVersion = response.getInt("AppVersion");


                } catch (JSONException e) {
                    e.printStackTrace();

                }
                hidepDialog();
                AppVersion av = new AppVersion(getApplicationContext());
                int version = av.Select_Detail();
                if (version < onlineVersion) {

                    Intent in = new Intent(MainActivity.this, Update.class);
                    startActivity(in);
                    finish();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {


                // hide the progress dialog
                hidepDialog();
            }
        });

        // Adding request to request queue


        AppController.getInstance().addToRequestQueue(jsonObjReq);
    }






    private void showpDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hidepDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }


}
