package com.gujaratit.design;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.gujaratit.R;
import com.gujaratit.adapter.ListAdapter;
import com.gujaratit.databasehelper.DatabaseHelper;
import com.gujaratit.model.GSCityDetail;
import com.gujaratit.model.GSCompanyDetail;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;

public class ListByCityActivity extends AppCompatActivity {

    DatabaseHelper DBHelper;
    Cursor cursor;
    Spinner spinnerSelectCity;
    ArrayList<GSCityDetail> CityList;
    ArrayList<GSCompanyDetail> CompanyDetailArrayList,TempList;
    TextView txtCompanyName,txtSite,txtCompanyID;
    ArrayList<String> FavouriteIDArray;
    int textlength = 0;
    String strCityName,strCityID;
    MaterialEditText edSearch;
    ListView myList;
    Typeface font;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_by_city);
        loadInitialView();
    }

    public void loadInitialView()
    {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DBHelper = new DatabaseHelper(getApplicationContext());
        CompanyDetailArrayList = new ArrayList<GSCompanyDetail>();
        TempList = new ArrayList<GSCompanyDetail>();
        FavouriteIDArray = new ArrayList<String>();
        spinnerSelectCity = (Spinner) findViewById(R.id.sp_select_city);
        edSearch = (MaterialEditText) findViewById(R.id.ed_search_city_list);
        final LinearLayout layoutListFilter = (LinearLayout) findViewById(R.id.layout_list_filter);
        myList = (ListView) findViewById(R.id.listview);
        final TextView txtSelectTitle = (TextView) findViewById(R.id.txt_select_title);
        font = Typeface.createFromAsset(getAssets(), "fontawesome-webfont.ttf");
        TextView txtFilterIcon = (TextView) findViewById(R.id.txt_filter);
        txtFilterIcon.setTypeface(font);
        loadFavouriteCompanyID();
        loadCityList();

        spinnerSelectCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                strCityName = spinnerSelectCity.getSelectedItem().toString();

                if (strCityName.equalsIgnoreCase("Select City")) {

                    layoutListFilter.setVisibility(View.INVISIBLE);
                    txtSelectTitle.setVisibility(View.INVISIBLE);

                } else {
                    layoutListFilter.setVisibility(View.VISIBLE);
                    txtSelectTitle.setVisibility(View.VISIBLE);
                    strCityID = CityList.get(position).getCityID();
                    cursor = DBHelper.getCompanyList(strCityID);
                    edSearch.setFloatingLabelAlwaysShown(true);
                    edSearch.setFloatingLabelText(String.valueOf(cursor.getCount()) + " Results");
                    CompanyDetailArrayList = new ArrayList<GSCompanyDetail>();
                    cursor.moveToFirst();
                    for (int i = 0; i < cursor.getCount(); i++) {
                        GSCompanyDetail beanCompanyDetail = new GSCompanyDetail();
                        beanCompanyDetail.setCompanyID(Integer.parseInt(cursor.getString(cursor.getColumnIndex("_id"))));
                        beanCompanyDetail.setCompanyName(cursor.getString(cursor.getColumnIndex("CompanyName")));
                        beanCompanyDetail.setWebsite(cursor.getString(cursor.getColumnIndex("Website")));
                        beanCompanyDetail.setCity(cursor.getString(cursor.getColumnIndex("city")));
                        CompanyDetailArrayList.add(beanCompanyDetail);
                        cursor.moveToNext();
                    }
                    myList.setAdapter(new ListAdapter(ListByCityActivity.this, CompanyDetailArrayList, FavouriteIDArray));
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        edSearch.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                TempList.clear();
                textlength = edSearch.getText().length();
                String SearchText = edSearch.getText().toString().trim();
                for (int i = 0; i < CompanyDetailArrayList.size(); i++) {
                    if (textlength <= CompanyDetailArrayList.get(i).getCompanyName().length()) {
                        if (CompanyDetailArrayList.get(i).getCompanyName().toUpperCase().contains(SearchText.toUpperCase())) {
                            TempList.add(CompanyDetailArrayList.get(i));
                        }
                    }
                }
                edSearch.setFloatingLabelText(String.valueOf(TempList.size()) + " Results");
                myList.setAdapter(new ListAdapter(ListByCityActivity.this, TempList, FavouriteIDArray));
            }
        });
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                txtCompanyName = (TextView) view.findViewById(R.id.txt_company_name);
                txtSite = (TextView) view.findViewById(R.id.txt_website);
                txtCompanyID = (TextView) view.findViewById(R.id.txt_company_id);
                Intent intent = new Intent(ListByCityActivity.this, CompanyDetailActivity.class);
                intent.putExtra("CompanyName", txtCompanyName.getText());
                intent.putExtra("WebSite", txtSite.getText());
                intent.putExtra("CompanyID", txtCompanyID.getText());
                startActivity(intent);
            }
        });
        myList.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                edSearch.requestFocus();
            }
        });
        myList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideSoftKeyboard(ListByCityActivity.this);
                return false;
            }
        });
        spinnerSelectCity.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideSoftKeyboard(ListByCityActivity.this);
                return false;
            }
        });
    }

    private void loadFavouriteCompanyID() {

        Cursor curr = DBHelper.getFavouriteCompanyID();
        curr.moveToFirst();
            for (int i = 0; i < curr.getCount(); i++) {
                FavouriteIDArray.add(i,curr.getString(curr.getColumnIndex("_id")));
                curr.moveToNext();
            }
    }

    private void loadCityList() {

        cursor = DBHelper.getCityList();
        CityList = new ArrayList<GSCityDetail>();
        final ArrayList<String> CityNames = new ArrayList<String>();
        cursor.moveToFirst();
        for (int i =0;i < cursor.getCount(); i++)
        {
            GSCityDetail beanCityDetail = new GSCityDetail();
            beanCityDetail.setCityID(cursor.getString(cursor.getColumnIndex("CityID")));
            beanCityDetail.setCityName(cursor.getString(cursor.getColumnIndex("CityName")));
            CityList.add(beanCityDetail);
            CityNames.add(i,cursor.getString(cursor.getColumnIndex("CityName")));
            cursor.moveToNext();
        }
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(ListByCityActivity.this, R.layout.spinner_item, CityNames) {
            @Override
            public int getCount() {
                return (CityNames.size());
            }
        };

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinnerSelectCity.setAdapter(adapter);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (String.valueOf(event.getKeyCode()) == String.valueOf(66)) {
            if (event.getAction() == event.ACTION_DOWN) {
                Log.i("key pressed", String.valueOf(event.getKeyCode()));
                hideSoftKeyboard(ListByCityActivity.this);
            }
        }
        return super.dispatchKeyEvent(event);
    }

    public static void hideSoftKeyboard(Activity activity) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
        catch (Exception e)
        {
            Log.d("Error","No keyboard");
        }
    }
}
