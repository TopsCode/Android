package com.gujaratit.design;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FilterQueryProvider;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.gujaratit.R;
import com.gujaratit.adapter.ListAdapter;
import com.gujaratit.databasehelper.DatabaseHelper;
import com.gujaratit.model.GSCompanyDetail;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;

public class ListByAlphabetActivity extends AppCompatActivity {

    Button btnA,btnB,btnC,btnD,btnE,btnF,btnG,btnH,btnI,btnJ,btnK,btnL,btnM,btnN,btnO,btnP,btnQ,btnR,btnS,btnT,btnU,btnV,btnW,btnX,btnY,btnZ,btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    String strAlphabet;
    DatabaseHelper DBHelper;
    Cursor cursor;
    ArrayList<String> FavouriteIDArray;
    ArrayList<GSCompanyDetail> CompanyDetailArrayList,TempList;
    Typeface font;
    LinearLayout layoutfilterAlphabet,layoutBtnAlphabet,layoutTopBtnAlphabet,layoutBottomBtnAlphabet,layoutNumberBtn;
    ListView myList;
    MaterialEditText edSearchAlphabet;
    TextView txtFilterIcon,txtCompanyName,txtSite,txtCompanyID;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_by_alphabet);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DBHelper = new DatabaseHelper(getApplicationContext());
        CompanyDetailArrayList = new ArrayList<GSCompanyDetail>();
        TempList = new ArrayList<GSCompanyDetail>();
        FavouriteIDArray = new ArrayList<String>();
        myList = (ListView) findViewById(R.id.listview_alphabet);
        layoutfilterAlphabet = (LinearLayout) findViewById(R.id.layout_list_alphabet_filter);
        layoutBtnAlphabet = (LinearLayout) findViewById(R.id.list_by_alphabet_btn_layout);
        layoutTopBtnAlphabet = (LinearLayout) findViewById(R.id.list_by_alphabet_btn_upper_layout);
        layoutBottomBtnAlphabet = (LinearLayout) findViewById(R.id.list_by_alphabet_btn_lower_layout);
        layoutNumberBtn = (LinearLayout) findViewById(R.id.list_by_alphabet_btn_number_layout);
        edSearchAlphabet = (MaterialEditText) findViewById(R.id.ed_search_alphabet_list);

        font = Typeface.createFromAsset(getAssets(), "fontawesome-webfont.ttf");
        txtFilterIcon = (TextView) findViewById(R.id.txt_filter);
        txtFilterIcon.setTypeface(font);
        loadFavouriteCompanyID();

        btn0 = (Button) findViewById(R.id.btn_0);
        btn1 = (Button) findViewById(R.id.btn_1);
        btn2 = (Button) findViewById(R.id.btn_2);
        btn3 = (Button) findViewById(R.id.btn_3);
        btn4 = (Button) findViewById(R.id.btn_4);
        btn5 = (Button) findViewById(R.id.btn_5);
        btn6 = (Button) findViewById(R.id.btn_6);
        btn7 = (Button) findViewById(R.id.btn_7);
        btn8 = (Button) findViewById(R.id.btn_8);
        btn9 = (Button) findViewById(R.id.btn_9);
        btnA = (Button) findViewById(R.id.btn_a);
        btnB = (Button) findViewById(R.id.btn_b);
        btnC = (Button) findViewById(R.id.btn_c);
        btnD = (Button) findViewById(R.id.btn_d);
        btnE = (Button) findViewById(R.id.btn_e);
        btnF = (Button) findViewById(R.id.btn_f);
        btnG = (Button) findViewById(R.id.btn_g);
        btnH = (Button) findViewById(R.id.btn_h);
        btnI = (Button) findViewById(R.id.btn_i);
        btnJ = (Button) findViewById(R.id.btn_j);
        btnK = (Button) findViewById(R.id.btn_k);
        btnL = (Button) findViewById(R.id.btn_l);
        btnM = (Button) findViewById(R.id.btn_m);
        btnN = (Button) findViewById(R.id.btn_n);
        btnO = (Button) findViewById(R.id.btn_o);
        btnP = (Button) findViewById(R.id.btn_p);
        btnQ = (Button) findViewById(R.id.btn_q);
        btnR = (Button) findViewById(R.id.btn_r);
        btnS = (Button) findViewById(R.id.btn_s);
        btnT = (Button) findViewById(R.id.btn_t);
        btnU = (Button) findViewById(R.id.btn_u);
        btnV = (Button) findViewById(R.id.btn_v);
        btnW = (Button) findViewById(R.id.btn_w);
        btnX = (Button) findViewById(R.id.btn_x);
        btnY = (Button) findViewById(R.id.btn_y);
        btnZ = (Button) findViewById(R.id.btn_z);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                txtCompanyName = (TextView) view.findViewById(R.id.txt_company_name);
                txtSite = (TextView) view.findViewById(R.id.txt_website);
                txtCompanyID = (TextView) view.findViewById(R.id.txt_company_id);
                Intent intent = new Intent(ListByAlphabetActivity.this, CompanyDetailActivity.class);
                intent.putExtra("CompanyName", txtCompanyName.getText());
                intent.putExtra("WebSite", txtSite.getText());
                intent.putExtra("CompanyID", txtCompanyID.getText());
                startActivity(intent);
            }
        });

        //Initially listview is created for Alphabet 'A'
        selectInitialAlphabet();

        edSearchAlphabet.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                TempList.clear();
                int textlength = edSearchAlphabet.getText().length();
                String SearchText = edSearchAlphabet.getText().toString().trim();
                for (int i = 0; i < CompanyDetailArrayList.size(); i++) {
                    if (textlength <= CompanyDetailArrayList.get(i).getCompanyName().length()) {
                        if (CompanyDetailArrayList.get(i).getCompanyName().toUpperCase().contains(SearchText.toUpperCase())) {
                            TempList.add(CompanyDetailArrayList.get(i));
                        }
                    }
                }
                edSearchAlphabet.setFloatingLabelText(String.valueOf(TempList.size()) + " Results");
                myList.setAdapter(new ListAdapter(ListByAlphabetActivity.this, TempList, FavouriteIDArray));
            }
        });
        myList.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                edSearchAlphabet.requestFocus();
            }
        });
        myList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideSoftKeyboard(ListByAlphabetActivity.this);
                return false;
            }
        });
    }

    private void selectInitialAlphabet() {

        btnA.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
        btnB.setTextColor(getResources().getColor(R.color.Interface));
        btnC.setTextColor(getResources().getColor(R.color.Interface));
        btnD.setTextColor(getResources().getColor(R.color.Interface));
        btnE.setTextColor(getResources().getColor(R.color.Interface));
        btnF.setTextColor(getResources().getColor(R.color.Interface));
        btnH.setTextColor(getResources().getColor(R.color.Interface));
        btnG.setTextColor(getResources().getColor(R.color.Interface));
        btnI.setTextColor(getResources().getColor(R.color.Interface));
        btnJ.setTextColor(getResources().getColor(R.color.Interface));
        btnK.setTextColor(getResources().getColor(R.color.Interface));
        btnL.setTextColor(getResources().getColor(R.color.Interface));
        btnM.setTextColor(getResources().getColor(R.color.Interface));
        btnN.setTextColor(getResources().getColor(R.color.Interface));
        btnO.setTextColor(getResources().getColor(R.color.Interface));
        btnP.setTextColor(getResources().getColor(R.color.Interface));
        btnQ.setTextColor(getResources().getColor(R.color.Interface));
        btnR.setTextColor(getResources().getColor(R.color.Interface));
        btnS.setTextColor(getResources().getColor(R.color.Interface));
        btnT.setTextColor(getResources().getColor(R.color.Interface));
        btnU.setTextColor(getResources().getColor(R.color.Interface));
        btnV.setTextColor(getResources().getColor(R.color.Interface));
        btnW.setTextColor(getResources().getColor(R.color.Interface));
        btnX.setTextColor(getResources().getColor(R.color.Interface));
        btnY.setTextColor(getResources().getColor(R.color.Interface));
        btnZ.setTextColor(getResources().getColor(R.color.Interface));
        btn0.setTextColor(getResources().getColor(R.color.Interface));
        btn1.setTextColor(getResources().getColor(R.color.Interface));
        btn2.setTextColor(getResources().getColor(R.color.Interface));
        btn3.setTextColor(getResources().getColor(R.color.Interface));
        btn4.setTextColor(getResources().getColor(R.color.Interface));
        btn5.setTextColor(getResources().getColor(R.color.Interface));
        btn6.setTextColor(getResources().getColor(R.color.Interface));
        btn7.setTextColor(getResources().getColor(R.color.Interface));
        btn8.setTextColor(getResources().getColor(R.color.Interface));
        btn9.setTextColor(getResources().getColor(R.color.Interface));

        int childcount = layoutBtnAlphabet.getChildCount();
        Log.d("childcount", String.valueOf(childcount));
        id = String.valueOf(R.id.btn_a);
        for (int i=0; i < childcount; i++) {
            if (i == 0) {
                for (int x = 0; x < layoutTopBtnAlphabet.getChildCount(); x++) {
                    View v = layoutTopBtnAlphabet.getChildAt(x);
                    if (id.equalsIgnoreCase(String.valueOf(v.getId()))) {
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_chagecolor));
                    } else {
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_background));
                    }
                }
            }
        }
        strAlphabet = "A";
        layoutfilterAlphabet.setVisibility(View.VISIBLE);
        cursor = DBHelper.getCompanyListByAlphabet(strAlphabet);
        edSearchAlphabet.setFloatingLabelAlwaysShown(true);
        edSearchAlphabet.setFloatingLabelText(String.valueOf(cursor.getCount()) + " Results");

        CompanyDetailArrayList = new ArrayList<GSCompanyDetail>();
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++) {
            GSCompanyDetail beanCompanyDetail = new GSCompanyDetail();
            beanCompanyDetail.setCompanyID(Integer.parseInt(cursor.getString(cursor.getColumnIndex("_id"))));
            beanCompanyDetail.setCompanyName(cursor.getString(cursor.getColumnIndex("CompanyName")));
            beanCompanyDetail.setWebsite(cursor.getString(cursor.getColumnIndex("Website")));
            beanCompanyDetail.setCity(cursor.getString(cursor.getColumnIndex("City")));
            CompanyDetailArrayList.add(beanCompanyDetail);
            cursor.moveToNext();
        }
        myList.setAdapter(new ListAdapter(ListByAlphabetActivity.this, CompanyDetailArrayList, FavouriteIDArray));
    }

    public void buttonOnClick(View view)
    {
        edSearchAlphabet.setText("");
        hideSoftKeyboard(ListByAlphabetActivity.this);
        switch(view.getId())
        {
            case R.id.btn_0:
                strAlphabet = "0";
                id = String.valueOf(R.id.btn_0);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_1:
                strAlphabet = "1";
                id = String.valueOf(R.id.btn_1);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_2:
                strAlphabet = "2";
                id = String.valueOf(R.id.btn_2);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_3:
                strAlphabet = "3";
                id = String.valueOf(R.id.btn_3);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_4:
                strAlphabet = "4";
                id = String.valueOf(R.id.btn_4);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_5:
                strAlphabet = "5";
                id = String.valueOf(R.id.btn_5);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_6:
                strAlphabet = "6";
                id = String.valueOf(R.id.btn_6);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_7:
                strAlphabet = "7";
                id = String.valueOf(R.id.btn_7);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;
            case R.id.btn_8:
                strAlphabet = "8";
                id = String.valueOf(R.id.btn_8);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_9:
                strAlphabet = "9";
                id = String.valueOf(R.id.btn_9);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                break;

            case R.id.btn_a:
                strAlphabet = "A";
                id = String.valueOf(R.id.btn_a);
                    btnA.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                    btnB.setTextColor(getResources().getColor(R.color.Interface));
                    btnC.setTextColor(getResources().getColor(R.color.Interface));
                    btnD.setTextColor(getResources().getColor(R.color.Interface));
                    btnE.setTextColor(getResources().getColor(R.color.Interface));
                    btnF.setTextColor(getResources().getColor(R.color.Interface));
                    btnH.setTextColor(getResources().getColor(R.color.Interface));
                    btnG.setTextColor(getResources().getColor(R.color.Interface));
                    btnI.setTextColor(getResources().getColor(R.color.Interface));
                    btnJ.setTextColor(getResources().getColor(R.color.Interface));
                    btnK.setTextColor(getResources().getColor(R.color.Interface));
                    btnL.setTextColor(getResources().getColor(R.color.Interface));
                    btnM.setTextColor(getResources().getColor(R.color.Interface));
                    btnN.setTextColor(getResources().getColor(R.color.Interface));
                    btnO.setTextColor(getResources().getColor(R.color.Interface));
                    btnP.setTextColor(getResources().getColor(R.color.Interface));
                    btnQ.setTextColor(getResources().getColor(R.color.Interface));
                    btnR.setTextColor(getResources().getColor(R.color.Interface));
                    btnS.setTextColor(getResources().getColor(R.color.Interface));
                    btnT.setTextColor(getResources().getColor(R.color.Interface));
                    btnU.setTextColor(getResources().getColor(R.color.Interface));
                    btnV.setTextColor(getResources().getColor(R.color.Interface));
                    btnW.setTextColor(getResources().getColor(R.color.Interface));
                    btnX.setTextColor(getResources().getColor(R.color.Interface));
                    btnY.setTextColor(getResources().getColor(R.color.Interface));
                    btnZ.setTextColor(getResources().getColor(R.color.Interface));
                    btn0.setTextColor(getResources().getColor(R.color.Interface));
                    btn1.setTextColor(getResources().getColor(R.color.Interface));
                    btn2.setTextColor(getResources().getColor(R.color.Interface));
                    btn3.setTextColor(getResources().getColor(R.color.Interface));
                    btn4.setTextColor(getResources().getColor(R.color.Interface));
                    btn5.setTextColor(getResources().getColor(R.color.Interface));
                    btn6.setTextColor(getResources().getColor(R.color.Interface));
                    btn7.setTextColor(getResources().getColor(R.color.Interface));
                    btn8.setTextColor(getResources().getColor(R.color.Interface));
                    btn9.setTextColor(getResources().getColor(R.color.Interface));

                break;

            case R.id.btn_b:
                strAlphabet = "B";
                id = String.valueOf(R.id.btn_b);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_c:
                strAlphabet = "C";
                id = String.valueOf(R.id.btn_c);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_d:
                strAlphabet = "D";
                id = String.valueOf(R.id.btn_d);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_e:
                strAlphabet = "E";
                id = String.valueOf(R.id.btn_e);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_f:
                strAlphabet = "F";
                id = String.valueOf(R.id.btn_f);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_g:
                strAlphabet = "G";
                id = String.valueOf(R.id.btn_g);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_h:
                strAlphabet = "H";
                id = String.valueOf(R.id.btn_h);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_i:
                strAlphabet = "I";
                id = String.valueOf(R.id.btn_i);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_j:
                strAlphabet = "J";
                id = String.valueOf(R.id.btn_j);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_k:
                strAlphabet = "K";
                id = String.valueOf(R.id.btn_k);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_l:
                strAlphabet = "L";
                id = String.valueOf(R.id.btn_l);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_m:
                strAlphabet = "M";
                id = String.valueOf(R.id.btn_m);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_n:
                strAlphabet = "N";
                id = String.valueOf(R.id.btn_n);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_o:
                strAlphabet = "O";
                id = String.valueOf(R.id.btn_o);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_p:
                strAlphabet = "P";
                id = String.valueOf(R.id.btn_p);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_q:
                strAlphabet = "Q";
                id = String.valueOf(R.id.btn_q);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_r:
                strAlphabet = "R";
                id = String.valueOf(R.id.btn_r);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_s:
                strAlphabet = "S";
                id = String.valueOf(R.id.btn_s);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_t:
                strAlphabet = "T";
                id = String.valueOf(R.id.btn_t);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_u:
                strAlphabet = "U";
                id = String.valueOf(R.id.btn_u);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_v:
                strAlphabet = "V";
                id = String.valueOf(R.id.btn_v);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_w:
                strAlphabet = "W";
                id = String.valueOf(R.id.btn_w);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_x:
                strAlphabet = "X";
                id = String.valueOf(R.id.btn_x);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_y:
                strAlphabet = "Y";
                id = String.valueOf(R.id.btn_y);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btnZ.setTextColor(getResources().getColor(R.color.Interface));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;

            case R.id.btn_z:
                strAlphabet = "Z";
                id = String.valueOf(R.id.btn_z);
                btnA.setTextColor(getResources().getColor(R.color.Interface));
                btnB.setTextColor(getResources().getColor(R.color.Interface));
                btnC.setTextColor(getResources().getColor(R.color.Interface));
                btnD.setTextColor(getResources().getColor(R.color.Interface));
                btnE.setTextColor(getResources().getColor(R.color.Interface));
                btnF.setTextColor(getResources().getColor(R.color.Interface));
                btnH.setTextColor(getResources().getColor(R.color.Interface));
                btnG.setTextColor(getResources().getColor(R.color.Interface));
                btnI.setTextColor(getResources().getColor(R.color.Interface));
                btnJ.setTextColor(getResources().getColor(R.color.Interface));
                btnK.setTextColor(getResources().getColor(R.color.Interface));
                btnL.setTextColor(getResources().getColor(R.color.Interface));
                btnM.setTextColor(getResources().getColor(R.color.Interface));
                btnN.setTextColor(getResources().getColor(R.color.Interface));
                btnO.setTextColor(getResources().getColor(R.color.Interface));
                btnP.setTextColor(getResources().getColor(R.color.Interface));
                btnQ.setTextColor(getResources().getColor(R.color.Interface));
                btnR.setTextColor(getResources().getColor(R.color.Interface));
                btnS.setTextColor(getResources().getColor(R.color.Interface));
                btnT.setTextColor(getResources().getColor(R.color.Interface));
                btnU.setTextColor(getResources().getColor(R.color.Interface));
                btnV.setTextColor(getResources().getColor(R.color.Interface));
                btnW.setTextColor(getResources().getColor(R.color.Interface));
                btnX.setTextColor(getResources().getColor(R.color.Interface));
                btnY.setTextColor(getResources().getColor(R.color.Interface));
                btnZ.setTextColor(getResources().getColor(R.color.BackgroundColorInView));
                btn0.setTextColor(getResources().getColor(R.color.Interface));
                btn1.setTextColor(getResources().getColor(R.color.Interface));
                btn2.setTextColor(getResources().getColor(R.color.Interface));
                btn3.setTextColor(getResources().getColor(R.color.Interface));
                btn4.setTextColor(getResources().getColor(R.color.Interface));
                btn5.setTextColor(getResources().getColor(R.color.Interface));
                btn6.setTextColor(getResources().getColor(R.color.Interface));
                btn7.setTextColor(getResources().getColor(R.color.Interface));
                btn8.setTextColor(getResources().getColor(R.color.Interface));
                btn9.setTextColor(getResources().getColor(R.color.Interface));
                break;
        }
        int childcount = layoutBtnAlphabet.getChildCount();
        Log.d("childcount", String.valueOf(childcount));
        for (int i=0; i < childcount; i++)
        {
            if(i == 0)
            {
                for (int x = 0;x<layoutNumberBtn.getChildCount();x++)
                {
                    View v = layoutNumberBtn.getChildAt(x);
                    if (id.equalsIgnoreCase(String.valueOf(v.getId())))
                    {
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_chagecolor));
                    }
                    else {
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_background));
                    }
                }
            }
            if(i == 1)
            {
                for (int x = 0;x<layoutTopBtnAlphabet.getChildCount();x++)
                {
                    View v = layoutTopBtnAlphabet.getChildAt(x);
                    if (id.equalsIgnoreCase(String.valueOf(v.getId())))
                    {
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_chagecolor));
                    }
                    else {
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_background));
                    }
                }
            }
            if(i == 2)
            {
                Log.d("selected id = ",id);
                for (int x = 0;x<layoutBottomBtnAlphabet.getChildCount();x++)
                {
                    View v = layoutBottomBtnAlphabet.getChildAt(x);
                    if (id.equalsIgnoreCase(String.valueOf(v.getId())))
                    {
                        Log.d("selected id -> ",String.valueOf(v.getId()));
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_chagecolor));
                    }
                    else {
                        Log.d("selected id -> ",String.valueOf(v.getId()));
                        v.setBackground(getResources().getDrawable(R.drawable.selector_btn_background));
                    }
                }
            }
        }
        layoutfilterAlphabet.setVisibility(View.VISIBLE);
        cursor = DBHelper.getCompanyListByAlphabet(strAlphabet);
        edSearchAlphabet.setFloatingLabelAlwaysShown(true);
        edSearchAlphabet.setFloatingLabelText(String.valueOf(cursor.getCount()) + " Results");

        CompanyDetailArrayList = new ArrayList<GSCompanyDetail>();
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++) {
            GSCompanyDetail beanCompanyDetail = new GSCompanyDetail();
            beanCompanyDetail.setCompanyID(Integer.parseInt(cursor.getString(cursor.getColumnIndex("_id"))));
            beanCompanyDetail.setCompanyName(cursor.getString(cursor.getColumnIndex("CompanyName")));
            beanCompanyDetail.setWebsite(cursor.getString(cursor.getColumnIndex("Website")));
            beanCompanyDetail.setCity(cursor.getString(cursor.getColumnIndex("City")));
            CompanyDetailArrayList.add(beanCompanyDetail);
            cursor.moveToNext();
        }
        myList.setAdapter(new ListAdapter(ListByAlphabetActivity.this, CompanyDetailArrayList, FavouriteIDArray));
    }
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (String.valueOf(event.getKeyCode()) == String.valueOf(66)) {
            if (event.getAction() == event.ACTION_DOWN) {
                Log.i("key pressed", String.valueOf(event.getKeyCode()));
                hideSoftKeyboard(ListByAlphabetActivity.this);
            }
        }
        return super.dispatchKeyEvent(event);
    }

    public static void hideSoftKeyboard(Activity activity) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
        catch (Exception e) {
            Log.d("Error","No keyboard");
        }
    }
    private void loadFavouriteCompanyID() {

        Cursor curr = DBHelper.getFavouriteCompanyID();
        curr.moveToFirst();
        for (int i = 0; i < curr.getCount(); i++) {
            FavouriteIDArray.add(i,curr.getString(curr.getColumnIndex("_id")));
            curr.moveToNext();
        }
    }
}