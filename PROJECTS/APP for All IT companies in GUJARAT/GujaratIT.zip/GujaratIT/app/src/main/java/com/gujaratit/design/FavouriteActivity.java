package com.gujaratit.design;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gujaratit.R;
import com.gujaratit.databasehelper.DatabaseHelper;

public class FavouriteActivity extends AppCompatActivity {

    DatabaseHelper DBHelper;
    Cursor cursor;
    SimpleCursorAdapter simpleCursorAdapter;
    TextView txtCompanyName,txtSite,txtCompanyID;
    ListView myList;
    int index;
    Toolbar toolbar;
    String strCompanyID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //this method loads required view,which is called multiple times.
        loadView();
    }
    @Override
    public void onResume() {
        super.onResume();
        loadView();
    }
    @Override
    public void onPause() {
        // Save ListView state @ onPause
        super.onPause();
        index = myList.getFirstVisiblePosition()+1;
    }

    public void loadView()
    {
        DBHelper = new DatabaseHelper(getApplicationContext());
        cursor = DBHelper.getFavoriteList();
        myList = (ListView) findViewById(R.id.listview_favourite);

        String[] columns = new String[]{"_id", "CompanyName", "Website"};
        int[] to = new int[]{R.id.txt_company_id, R.id.txt_company_name, R.id.txt_website};

        simpleCursorAdapter = new SimpleCursorAdapter(getApplicationContext(),
                R.layout.listview_row_item, cursor, columns, to);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            myList.setAdapter(simpleCursorAdapter);
        }
        else{
            myList.setAdapter(null);
            Toast.makeText(FavouriteActivity.this, "There are no favourites", Toast.LENGTH_SHORT).show();
        }
        myList.setSelectionFromTop(index, 0);
        registerForContextMenu(myList);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                txtCompanyName = (TextView) view.findViewById(R.id.txt_company_name);
                txtSite = (TextView) view.findViewById(R.id.txt_website);
                txtCompanyID = (TextView) view.findViewById(R.id.txt_company_id);
                Intent intent = new Intent(FavouriteActivity.this, CompanyDetailActivity.class);
                intent.putExtra("CompanyName", txtCompanyName.getText());
                intent.putExtra("WebSite", txtSite.getText());
                intent.putExtra("CompanyID", txtCompanyID.getText());
                startActivity(intent);
            }
        });
        myList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                TextView txtCompanyID = (TextView) view.findViewById(R.id.txt_company_id);
                strCompanyID = txtCompanyID.getText().toString();
                return false;
            }
        });
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        AdapterView.AdapterContextMenuInfo info;
        try {
            info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        } catch (ClassCastException e) {

            return;
        }
        menu.add("Remove from favourite");
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {

        new AlertDialog.Builder(new ContextThemeWrapper(FavouriteActivity.this,
                android.R.style.Theme_Holo_Light_Dialog))

                .setIcon(android.R.drawable.ic_dialog_alert) // icon that you want
                .setTitle("Confirm") // title of your dialog
                .setMessage("Are you sure want to remove it from favourite?") // message of dialog
                .setPositiveButton("Yes", // String for positive
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // do positive action here
                                DBHelper.removeFavorite(strCompanyID);

                                loadView();
                            }
                        }).setNegativeButton("No", // String for negative action
                null).show();

        return super.onContextItemSelected(item);
    }
}
