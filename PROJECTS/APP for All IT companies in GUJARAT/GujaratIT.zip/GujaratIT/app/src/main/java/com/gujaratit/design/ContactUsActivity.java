package com.gujaratit.design;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gujaratit.R;
import com.gujaratit.constant.Constant;

public class ContactUsActivity extends AppCompatActivity {

    Button btnemail,btnmsg;
    EditText edmsg;
    String msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        btnemail = (Button) findViewById(R.id.contact_us_btn_email);
        btnmsg = (Button) findViewById(R.id.contact_us_btn_sms);
        edmsg = (EditText) findViewById(R.id.contact_us_ed_msg);

        btnemail.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                msg = edmsg.getText().toString();
                if (msg.length() > 0) {
                    hideSoftKeyboard(ContactUsActivity.this);
                    Intent intent = new Intent(Intent.ACTION_SENDTO); // it's
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_SUBJECT, "From GujaratIT");
                    intent.putExtra(Intent.EXTRA_TEXT, msg);
                    intent.setData(Uri.parse("mailto:"+ Constant.AdminEmailAddress)); // or
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // this will
                    try {
                        startActivity(intent);

                        finish();
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(ContactUsActivity.this,
                                "There are no email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(ContactUsActivity.this, "Enter some text", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                msg = edmsg.getText().toString();
                if (msg.length() > 0) {
                    hideSoftKeyboard(ContactUsActivity.this);
                    new AlertDialog.Builder(new ContextThemeWrapper(ContactUsActivity.this,
                            android.R.style.Theme_Holo_Light_Dialog))

                            .setIcon(android.R.drawable.ic_dialog_alert) // icon that you want
                            .setTitle("Confirm") // title of your dialog
                            .setMessage("Are you sure want to send this SMS?") // message of dialog
                            .setPositiveButton("Yes", // String for positive
                                    new DialogInterface.OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog,
                                                            int which) {
                                            sayHello();
                                        }
                                    }).setNegativeButton("No", // String for negative action
                            null).show();
                }
                else {
                    Toast.makeText(ContactUsActivity.this, "Enter some text", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void sayHello() {

        PendingIntent sentPI = PendingIntent.getBroadcast(this, 0, new Intent(
                "SMS_Sent"), 0);

        // ---when the SMS has been sent---
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS sent",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), "Generic failure",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(getBaseContext(), "No service",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        Toast.makeText(getBaseContext(), "Null PDU",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        Toast.makeText(getBaseContext(), "Radio off",
                                Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_Sent"));

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS delivered",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getBaseContext(), "SMS not delivered",
                                Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("DELIVERED"));

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(Constant.AdminMobileNo, null, "GujaratIT: " + msg, sentPI, null);
    }
    public static void hideSoftKeyboard(Activity activity) {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
        catch (Exception e)
        {
            Log.d("Error", "No keyboard");
        }
    }
}
