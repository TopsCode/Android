package com.gujaratit.databasehelper;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.gujaratit.constant.Constant;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class AppVersion extends SQLiteAssetHelper {


    @SuppressLint("SdCardPath")
    public AppVersion(Context context) {
        super(context, Constant.DATABASE_NAME, null, Constant.DBTABASE_VERSION);
    }

    @SuppressLint("NewApi")
    public void Insert_Detail(int App) {

        SQLiteDatabase db = getWritableDatabase();

        db.delete("MST_Version", null, null);
        ContentValues insertValues = new ContentValues();
        insertValues.put("VersionID", 1);
        insertValues.put("VersionNumber", App);
        db.insert("MST_Version", null, insertValues);
        db.close();

    }

    public int Select_Detail() {
        int a = 0;

        SQLiteDatabase db = getReadableDatabase();
        String query = "select * from MST_Version";
        Cursor cursor_access_database = db.rawQuery(query, null);
        if (cursor_access_database.getCount() > 0) {
            cursor_access_database.moveToFirst();
            a = (cursor_access_database.getInt(cursor_access_database.getColumnIndex("VersionNumber")));
        }

        db.close();
        return a;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        /*db.execSQL("DELETE FROM mf_meritno");
		onCreate(db);*/
    }

}