package com.gujaratit.design;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gujaratit.R;
import com.gujaratit.databasehelper.DatabaseHelper;
import com.rengwuxian.materialedittext.MaterialAutoCompleteTextView;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;

public class SuggestNewCompanyActivity extends AppCompatActivity {

    MaterialEditText edCompanyName,edAddress,edWebsite,edEmail,edPhoneNo,edMobileNo;
    TextView txtCompanyName,txtAddress,txtWebsite,txtEmail,txtPhoneNo,txtMobileNo,txtCity;
    MaterialAutoCompleteTextView edCity;
    DatabaseHelper DBHelper;
    Cursor cursor;
    Typeface font;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggest_new_company);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtCompanyName = (TextView) findViewById(R.id.txt_company_icon);
        txtAddress = (TextView) findViewById(R.id.txt_address_icon);
        txtCity = (TextView) findViewById(R.id.txt_city_icon);
        txtWebsite = (TextView) findViewById(R.id.txt_website_icon);
        txtEmail = (TextView) findViewById(R.id.txt_email_icon);
        txtPhoneNo = (TextView) findViewById(R.id.txt_phone_icon);
        txtMobileNo = (TextView) findViewById(R.id.txt_mobile_icon);

        edCompanyName = (MaterialEditText) findViewById(R.id.ed_company);
        edAddress = (MaterialEditText) findViewById(R.id.ed_address);
        edCity = (MaterialAutoCompleteTextView) findViewById(R.id.ed_city);
        edWebsite = (MaterialEditText) findViewById(R.id.ed_site);
        edEmail = (MaterialEditText) findViewById(R.id.ed_mail);
        edPhoneNo = (MaterialEditText) findViewById(R.id.ed_phone);
        edMobileNo = (MaterialEditText) findViewById(R.id.ed_mobile);
        final Button btnAdd = (Button) findViewById(R.id.btn_add);

        font = Typeface.createFromAsset(getAssets(), "MaterialIcons-Regular.ttf");
        txtCompanyName.setTypeface(font);
        txtAddress.setTypeface(font);
        txtCity.setTypeface(font);
        txtWebsite.setTypeface(font);
        txtEmail.setTypeface(font);
        txtPhoneNo.setTypeface(font);
        txtMobileNo.setTypeface(font);

        DBHelper = new DatabaseHelper(getApplicationContext());
        loadCityList();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isOnline())
                {
                    if (edCompanyName.getText().toString().trim().equalsIgnoreCase("") && edCity.getText().toString().trim().equalsIgnoreCase("")) {
                        edCompanyName.setError("Enter Proper Company Name");
                        edCity.setError("Enter Proper City Name");
                        if (edCompanyName.getText().toString().trim().equalsIgnoreCase("")) {
                            edCompanyName.setError("Enter Proper Company Name");
                        } else {
                            edCity.setError("Enter Proper City Name");
                        }
                    }
                    else
                    {
                        Boolean check = true;
                        if (!edEmail.getText().toString().trim().equalsIgnoreCase("")){
                            if (!isValidEmail(edEmail.getText().toString())){
                                edEmail.setError("Enter Proper Email");
                                check = false;
                            }
                        }
                        if (!edMobileNo.getText().toString().trim().equalsIgnoreCase("")){
                            if (edMobileNo.getText().length() != 10){
                                edMobileNo.setError("Enter Proper Number");
                                check = false;
                            }
                        }
                        if (!edWebsite.getText().toString().trim().equalsIgnoreCase("")) {
                            if (!isValidWebsite(edWebsite.getText().toString())) {
                                edWebsite.setError("Enter Proper Website");
                                check = false;
                            }
                        }
                        if (check)
                        {
                             String strVerificationEmail ="CompanyName : "+String.valueOf(edCompanyName.getText())
                                     +"\n Address : "+String.valueOf(edAddress.getText())
                                     +"\n City : "+String.valueOf(edCity.getText())
                                     +"\n Website : "+String.valueOf(edWebsite.getText())
                                     +"\n Email : "+String.valueOf(edEmail.getText())
                                     +"\n PhoneNo : "+String.valueOf(edPhoneNo.getText())
                                     +"\n MobileNo : "+String.valueOf(edMobileNo.getText());

                            Intent intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setType("text/plain");
                            intent.putExtra(Intent.EXTRA_SUBJECT, "From GujaratIT");
                            intent.putExtra(Intent.EXTRA_TEXT, strVerificationEmail);
                            intent.setData(Uri.parse("mailto:info@admissionapps.com"));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            try {
                                startActivity(intent);
                                finish();
                            } catch (android.content.ActivityNotFoundException ex) {
                                Toast.makeText(SuggestNewCompanyActivity.this,
                                        "There are no email clients installed.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
                else {
                    Toast.makeText(SuggestNewCompanyActivity.this, "No Interet Connectivity", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadCityList() {

        cursor = DBHelper.getCityList();
        final ArrayList<String> CityNames = new ArrayList<String>();
        cursor.moveToFirst();
        for (int i =0;i< cursor.getCount(); i++)
        {
            CityNames.add(i,cursor.getString(cursor.getColumnIndex("CityName")));
            cursor.moveToNext();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,CityNames);
        edCity.setAdapter(adapter);
        edCity.setThreshold(1);
    }
    public final static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
    public final static boolean isValidWebsite(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util. Patterns.WEB_URL.matcher(target).matches();
    }

    protected boolean isOnline() {
        ConnectivityManager connectivity = (ConnectivityManager) this
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
        }
        return false;
    }
}
