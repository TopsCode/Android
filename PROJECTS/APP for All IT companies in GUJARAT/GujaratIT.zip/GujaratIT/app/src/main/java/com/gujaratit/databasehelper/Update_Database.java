package com.gujaratit.databasehelper;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.gujaratit.constant.Constant;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class Update_Database extends SQLiteAssetHelper {

	
	
	@SuppressLint("SdCardPath")
	
	

	public Update_Database(Context context) {
		super(context, Constant.DATABASE_NAME, null,Constant.DBTABASE_VERSION);

		

	}

	@SuppressLint("NewApi")
	public void Insert_Detail(ArrayList <String> App) {

		SQLiteDatabase db = getWritableDatabase();
		db.delete("LOC_State",null,null);
		db.delete("LOC_City",null,null);
		db.delete("CMP_SuggestedCompany",null,null);
		db.delete("CMP_Favourite",null,null);
		db.delete("CMP_Company",null,null);

		for(int i=0;i<App.size();i++)
		{
			db.execSQL(App.get(i).toString());
		}
		db.close();

	}

	

}