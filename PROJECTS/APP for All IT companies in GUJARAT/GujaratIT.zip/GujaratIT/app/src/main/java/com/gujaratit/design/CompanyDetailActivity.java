package com.gujaratit.design;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gujaratit.R;
import com.gujaratit.databasehelper.DatabaseHelper;


public class CompanyDetailActivity extends AppCompatActivity {

    private Cursor cur,curr;
    Boolean check = false;
    String strAdd,strRemove,strCompanyName,strWebsite,strCompanyID;
    TextView txtCompanyName,txtAddress,txtCity,txtSite,txtEmail,txtPhone,txtMobile;
    TextView txtAddressIcon,txtCityIcon,txtSiteIcon,txtEmailIcon,txtPhoneIcon,txtMobileIcon;
    LinearLayout layoutAddress,layoutCity,layoutwebsite,layoutEmail,layoutPhone,layoutMobile;
    DatabaseHelper DBHelper;
    Typeface font;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //get required string from intent of previous screen
        strCompanyName = getIntent().getStringExtra("CompanyName");
        strWebsite = getIntent().getStringExtra("WebSite");
        strCompanyID = getIntent().getStringExtra("CompanyID");
        strAdd = "Add to Favourite";
        strRemove = "Remove From Favourite";

        //Intialize textview for details
        txtCompanyName = (TextView) findViewById(R.id.company_detail_txt_company_name);
        txtAddress = (TextView) findViewById(R.id.company_detail_txt_address);
        txtCity = (TextView) findViewById(R.id.company_detail_txt_city);
        txtSite = (TextView) findViewById(R.id.company_detail_txt_site);
        txtEmail = (TextView) findViewById(R.id.company_detail_txt_mail);
        txtPhone = (TextView) findViewById(R.id.company_detail_txt_phone);
        txtMobile = (TextView) findViewById(R.id.company_detail_txt_mobile);

        //Initialize icons for textview
        txtAddressIcon = (TextView) findViewById(R.id.company_detail_txt_address_icon);
        txtCityIcon = (TextView) findViewById(R.id.company_detail_txt_city_icon);
        txtSiteIcon = (TextView) findViewById(R.id.company_detail_txt_website_icon);
        txtEmailIcon = (TextView) findViewById(R.id.company_detail_txt_email_icon);
        txtPhoneIcon = (TextView) findViewById(R.id.company_detail_txt_phone_icon);
        txtMobileIcon = (TextView) findViewById(R.id.company_detail_txt_mobile_icon);

        font = Typeface.createFromAsset(getAssets(), "MaterialIcons-Regular.ttf");
        txtAddressIcon.setTypeface(font);
        txtCityIcon.setTypeface(font);
        txtSiteIcon.setTypeface(font);
        txtEmailIcon.setTypeface(font);
        txtPhoneIcon.setTypeface(font);
        txtMobileIcon.setTypeface(font);

        layoutAddress = (LinearLayout) findViewById(R.id.detail_address);
        layoutCity = (LinearLayout) findViewById(R.id.detail_city);
        layoutwebsite = (LinearLayout) findViewById(R.id.detail_website);
        layoutEmail = (LinearLayout) findViewById(R.id.detail_email);
        layoutPhone = (LinearLayout) findViewById(R.id.detail_phone);
        layoutMobile = (LinearLayout) findViewById(R.id.detail_mobile);

        txtSite.setText(strWebsite);
        txtCompanyName.setText(strCompanyName);
        DBHelper = new DatabaseHelper(getApplicationContext());
        cur = DBHelper.getCompanyDetails(strCompanyID);

        cur.moveToFirst();
        if (cur.getString(cur.getColumnIndex("Address")) == null)
        {
            layoutAddress.setVisibility(View.GONE);
        }
        else {
            txtAddress.setText(cur.getString(cur.getColumnIndex("Address")));
        }

        if (cur.getString(cur.getColumnIndex("City")) == null)
        {
            layoutCity.setVisibility(View.GONE);
        }
        else {
            txtCity.setText(cur.getString(cur.getColumnIndex("City")));
        }

        if (cur.getString(cur.getColumnIndex("Website")) == null)
        {
            layoutwebsite.setVisibility(View.GONE);
        }
        else {
            txtSite.setText(cur.getString(cur.getColumnIndex("Website")));
        }

        if (cur.getString(cur.getColumnIndex("Email")) == null)
        {
            layoutEmail.setVisibility(View.GONE);
        }
        else {
            txtEmail.setText(cur.getString(cur.getColumnIndex("Email")));
        }

        if (cur.getString(cur.getColumnIndex("PhoneNo")) == null)
        {
            layoutPhone.setVisibility(View.GONE);
        }
        else {
            txtPhone.setText(cur.getString(cur.getColumnIndex("PhoneNo")));
        }

        if (cur.getString(cur.getColumnIndex("Mobile")) == null)
        {
            layoutMobile.setVisibility(View.GONE);
        }
        else {
            txtMobile.setText(cur.getString(cur.getColumnIndex("Mobile")));
        }

        final Button btnFavourite = (Button) findViewById(R.id.btn_add_favourite);
        curr = DBHelper.getCompanyID();
        curr.moveToFirst();

        for (int i =0;i< curr.getCount(); i++)
        {
            Log.d("dataaaaa",curr.getString(curr.getColumnIndex("CompanyID")));
            if (strCompanyID.equalsIgnoreCase(curr.getString(curr.getColumnIndex("CompanyID"))))
            {
                check = true;
                break;
            }
            curr.moveToNext();
        }
        if (check)
        {
            btnFavourite.setText(strRemove);
        }
        else
        {
            btnFavourite.setText(strAdd);
        }
        btnFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (strAdd.equalsIgnoreCase(btnFavourite.getText().toString())) {
                    DBHelper.addFavorite(strCompanyID, strCompanyName, strWebsite);
                    Toast.makeText(getApplicationContext(),"Successfully Added As Favourite",Toast.LENGTH_SHORT).show();
                    btnFavourite.setText(strRemove);
                }
                else {
                    DBHelper.removeFavorite(strCompanyID);
                    Toast.makeText(getApplicationContext(),"Removed From Favourite",Toast.LENGTH_SHORT).show();
                    btnFavourite.setText(strAdd);
                }
            }
        });
        txtMobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mobileIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:+91" + txtMobile.getText().toString().trim()));
                mobileIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(mobileIntent);
            }
        });
        txtPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mobileIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + txtPhone.getText().toString().trim()));
                mobileIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(mobileIntent);
            }
        });
    }
}
