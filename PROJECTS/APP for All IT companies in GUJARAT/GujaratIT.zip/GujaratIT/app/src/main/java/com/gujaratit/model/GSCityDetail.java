package com.gujaratit.model;

/**
 * Created by Wilson on 10/2/2015.
 */
public class GSCityDetail {
    private String CityName;
    private String CityID;

    public String getCityName() {
        return CityName;
    }

    public void setCityName(String cityName) {
        CityName = cityName;
    }

    public String getCityID() {
        return CityID;
    }

    public void setCityID(String cityID) {
        CityID = cityID;
    }
}
