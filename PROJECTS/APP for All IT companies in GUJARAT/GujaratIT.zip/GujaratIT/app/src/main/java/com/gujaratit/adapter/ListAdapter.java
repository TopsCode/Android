package com.gujaratit.adapter;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gujaratit.R;
import com.gujaratit.model.GSCompanyDetail;

import java.util.ArrayList;

/**
 * Created by Wilson on 10/10/2015.
 */
public class ListAdapter extends BaseAdapter {

    Activity cntx;
    ArrayList<GSCompanyDetail> CompanyDetailList;
    ArrayList<String> FavouriteIDArray;
    Typeface font;

    public ListAdapter(Activity context, ArrayList<GSCompanyDetail> CompanyArray, ArrayList<String> FavouriteArray)
    {
        this.cntx = context;
        this.CompanyDetailList = CompanyArray;
        this.FavouriteIDArray = FavouriteArray;
    }

    public int getCount()
    {
        return CompanyDetailList.size();
    }
    public Object getItem(int position)
    {
        return CompanyDetailList.get(position);
    }

    public long getItemId(int position)
    {
        return CompanyDetailList.size();
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        View row = null;
        LayoutInflater inflater = cntx.getLayoutInflater();
        font = Typeface.createFromAsset(cntx.getAssets(), "MaterialIcons-Regular.ttf");
        row = inflater.inflate(R.layout.listview_row_item, null);
        TextView txtCompanyName = (TextView) row.findViewById(R.id.txt_company_name);
        TextView txtWebsite = (TextView) row.findViewById(R.id.txt_website);
        TextView txtCompanyID = (TextView) row.findViewById(R.id.txt_company_id);
        TextView txtStarIcon = (TextView) row.findViewById(R.id.txt_star_icon);
        txtCompanyID.setText(Integer.toString(CompanyDetailList.get(position).getCompanyID()));
        txtCompanyName.setText(CompanyDetailList.get(position).getCompanyName());
        String strWebsite = CompanyDetailList.get(position).getWebsite();
        String strCity = CompanyDetailList.get(position).getCity();

        for (int i = 0 ; i< FavouriteIDArray.size();i++)
        {
            if (txtCompanyID.getText().toString().equalsIgnoreCase(FavouriteIDArray.get(i)))
            {
                txtStarIcon.setVisibility(View.VISIBLE);
                txtStarIcon.setTypeface(font);
            }
        }

        if (strWebsite == null && strCity == null)
        {
            txtWebsite.setText("-");
        }
        else if (strWebsite == null)
        {
            txtWebsite.setText(strCity);
        }
        else if (strCity == null)
        {
            txtWebsite.setText(strWebsite);
        }
        else {
            txtWebsite.setText(strWebsite+", "+strCity.toUpperCase());
        }
        return row;
    }
}
