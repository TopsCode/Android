package com.gujaratit.databasehelper;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.gujaratit.constant.Constant;
import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DatabaseHelper extends SQLiteAssetHelper {
    Context myContext;
    SQLiteDatabase db;
    public DatabaseHelper(Context context) {
        super(context, Constant.DATABASE_NAME, null,Constant.DBTABASE_VERSION);
        this.myContext = context;
    }

    public Cursor getCityList()
    {
        db = getReadableDatabase();
        String query = "Select cityid,cityname From loc_city  ORDER BY cityname ";
        return db.rawQuery(query,null);
    }

    public Cursor getCompanyList(String CityID)
    {
        db = getReadableDatabase();
        String query = "Select co.CompanyID as _id,co.CompanyName,co.Website,ci.CityName as city from CMP_Company co inner join LOC_City ci on co.CityID=ci.CityID where co.CityID ="+CityID+" ORDER BY CompanyName";
        return db.rawQuery(query,null);
    }
    public   Cursor getCompanyDetails(String CompanyID)
    {
        db = getReadableDatabase();
        String query = "Select co.Address,co.Website,co.Email,co.PhoneNo,co.Mobile,ci.CityName as City from CMP_Company co inner join LOC_City ci on co.CityID=ci.CityID where co.CompanyID ="+CompanyID;
        return db.rawQuery(query, null);
    }

    public  Cursor QuickSearchCompanyList(String value)
    {
        db = getReadableDatabase();
        String query = "SELECT co.CompanyID as _id,co.CompanyName,co.Website,ci.CityName as City from CMP_Company co inner join LOC_City as ci on co.CityID = ci.CityID where co.CompanyName like '%"+value+"%' OR ci.CityName like '%"+value+"%' OR co.Website like '%"+value+"%' OR co.Email like '%"+value+"%' OR co.PhoneNo like '%"+value+"%' OR co.Mobile like '%"+value+"%' ORDER BY co.CompanyName";
        return db.rawQuery(query, null);
    }

    public Cursor getCompanyListByAlphabet(String alphabet) {
        db = getReadableDatabase();
        String query = "Select co.CompanyID as _id,co.CompanyName,co.Website,ci.CityName as City From CMP_Company co inner join LOC_City as ci on co.CityID = ci.CityID Where co.CompanyName like '"+alphabet+"%' ORDER BY co.CompanyName";
        return db.rawQuery(query, null);
    }

    public Cursor getCompanyID() {
        db = getReadableDatabase();
        String query = "Select CompanyID From CMP_Favourite";
        return db.rawQuery(query, null);
    }

    public void addFavorite(String companyID,String companyName,String website)
    {
        db = this.getWritableDatabase();
        String query = "Insert into CMP_Favourite(CompanyID,CompanyName,Website) values('"+companyID+"','"+companyName+"','"+website+"')";
        db.execSQL(query);
    }

    public void removeFavorite(String CompanyID)
    {
        db = this.getWritableDatabase();
        String query = "DELETE FROM CMP_Favourite WHERE CompanyID = '"+CompanyID+"'";
        db.execSQL(query);
    }

    public Cursor getFavoriteList() {
        db = getReadableDatabase();
        String query = "Select CompanyID as _id,CompanyName,Website From CMP_Favourite ORDER BY companyname ASC ";
        return db.rawQuery(query, null);
    }

    public Cursor getFavouriteCompanyID()
    {
        db = getReadableDatabase();
        String query = "Select CompanyID as _id FROM CMP_Favourite ORDER BY companyname";
        return db.rawQuery(query, null);
    }
}