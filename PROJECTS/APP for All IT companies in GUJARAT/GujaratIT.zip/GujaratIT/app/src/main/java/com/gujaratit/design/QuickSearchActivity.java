package com.gujaratit.design;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.gujaratit.R;
import com.gujaratit.adapter.ListAdapter;
import com.gujaratit.databasehelper.DatabaseHelper;
import com.gujaratit.model.GSCompanyDetail;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;

public class QuickSearchActivity extends AppCompatActivity {

    DatabaseHelper DBHelper;
    Cursor cursor;
    int textlength = 0;
    String strValue;
    ArrayList<GSCompanyDetail> CompanyDetailArrayList,TempList;
    ArrayList<String> FavouriteIDArray;
    Typeface SearchFont,FilterFont;
    TextView txtSearchIcon,txtFilterIcon,txtCompanyName,txtSite,txtCompanyID;;
    MaterialEditText edSearchChild;
    EditText edSearchParent;
    ListView myList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        myList = (ListView) findViewById(R.id.listview_quick_search);
        edSearchParent = (EditText) findViewById(R.id.quicksearch_ed_search_parent);
        edSearchChild = (MaterialEditText) findViewById(R.id.quicksearch_ed_search_child);
        TempList = new ArrayList<GSCompanyDetail>();
        FavouriteIDArray = new ArrayList<String>();
        DBHelper = new DatabaseHelper(getApplicationContext());
        strValue = getIntent().getStringExtra("SearchValue");

        SearchFont = Typeface.createFromAsset(getAssets(), "MaterialIcons-Regular.ttf");
        FilterFont = Typeface.createFromAsset(getAssets(), "fontawesome-webfont.ttf");
        txtSearchIcon = (TextView) findViewById(R.id.quicksearch_txt_search_icon);
        txtFilterIcon = (TextView) findViewById(R.id.quicksearch_txt_filter_icon);
        txtSearchIcon.setTypeface(SearchFont);
        txtFilterIcon.setTypeface(FilterFont);
        edSearchParent.setText(strValue);
        loadFavouriteCompanyID();
        loadParentFilter();

        edSearchChild.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
            }
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                TempList.clear();
                textlength = edSearchChild.getText().length();
                String SearchText = edSearchChild.getText().toString().trim();
                for (int i = 0; i < CompanyDetailArrayList.size(); i++) {
                    if (textlength <= CompanyDetailArrayList.get(i).getCompanyName().length()) {
                        if (CompanyDetailArrayList.get(i).getCompanyName().toUpperCase().contains(SearchText.toUpperCase())) {
                            TempList.add(CompanyDetailArrayList.get(i));
                        }
                    }
                }
                edSearchChild.setFloatingLabelText(String.valueOf(TempList.size()) + " Results");
                myList.setAdapter(new ListAdapter(QuickSearchActivity.this, TempList,FavouriteIDArray));
            }
        });

        txtSearchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadParentFilter();
            }
        });

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                txtCompanyName = (TextView) view.findViewById(R.id.txt_company_name);
                txtSite = (TextView) view.findViewById(R.id.txt_website);
                txtCompanyID = (TextView) view.findViewById(R.id.txt_company_id);
                Intent intent = new Intent(QuickSearchActivity.this, CompanyDetailActivity.class);
                intent.putExtra("CompanyName", txtCompanyName.getText());
                intent.putExtra("WebSite", txtSite.getText());
                intent.putExtra("CompanyID", txtCompanyID.getText());
                startActivity(intent);
            }
        });
        myList.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                edSearchChild.requestFocus();
            }
        });
        myList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideSoftKeyboard(QuickSearchActivity.this);
                return false;
            }
        });
        edSearchChild.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                hideSoftKeyboard(QuickSearchActivity.this);
            }
        });
    }

    private void loadParentFilter() {

        strValue = edSearchParent.getText().toString();
        cursor = DBHelper.QuickSearchCompanyList(String.valueOf(strValue));
        edSearchChild.setText("");
        edSearchChild.requestFocus();
        edSearchChild.setFloatingLabelAlwaysShown(true);
        edSearchChild.setFloatingLabelText(String.valueOf(cursor.getCount()) + " Results");
        CompanyDetailArrayList = new ArrayList<GSCompanyDetail>();
        cursor.moveToFirst();
        for (int i = 0; i < cursor.getCount(); i++)
        {
            GSCompanyDetail beanCompanyDetail = new GSCompanyDetail();
            beanCompanyDetail.setCompanyID(Integer.parseInt(cursor.getString(cursor.getColumnIndex("_id"))));
            beanCompanyDetail.setCompanyName(cursor.getString(cursor.getColumnIndex("CompanyName")));
            beanCompanyDetail.setWebsite(cursor.getString(cursor.getColumnIndex("Website")));
            beanCompanyDetail.setCity(cursor.getString(cursor.getColumnIndex("City")));
            CompanyDetailArrayList.add(beanCompanyDetail);
            cursor.moveToNext();
        }
        myList.setAdapter(new ListAdapter(QuickSearchActivity.this,CompanyDetailArrayList,FavouriteIDArray));
        edSearchParent.setText(strValue);
    }

    private void loadFavouriteCompanyID() {

        Cursor curr = DBHelper.getFavouriteCompanyID();
        curr.moveToFirst();
        for (int i = 0; i < curr.getCount(); i++) {
            FavouriteIDArray.add(i, curr.getString(curr.getColumnIndex("_id")));
            curr.moveToNext();
        }
    }
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (String.valueOf(event.getKeyCode()) == String.valueOf(66)) {
            if (event.getAction() == event.ACTION_DOWN) {
                Log.i("key pressed", String.valueOf(event.getKeyCode()));
                loadParentFilter();
                hideSoftKeyboard(QuickSearchActivity.this);
            }
        }
        return super.dispatchKeyEvent(event);
    }
    public static void hideSoftKeyboard(Activity activity) {
            try {
                InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
            }
            catch (Exception e) {
                Log.d("Error","No keyboard");
            }
    }
}