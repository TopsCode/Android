package com.gujaratit.constant;

/**
 * Created by Wilson on 10/2/2015.
 */
public class Constant {

    public static final int DBTABASE_VERSION = 5;
    public static final String DATABASE_NAME = "gws_gujaratit5.s3db";
    public static final String AdminEmailAddress = "aswdc.android@darshan.ac.in";
    public static final String AdminMobileNo = "919898324788";
    public static final String ASWDCEmailAddress = "aswdc.android@darshan.ac.in";
    public static final String AppPlayStoreLink = "https://play.google.com/store/apps/details?id=com.gujaratit";
}
