package com.gujaratit.design;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gujaratit.BuildConfig;
import com.gujaratit.R;
import com.gujaratit.constant.Constant;


public class DeveloperActivity extends AppCompatActivity {

    TextView icmail, icphone, icweb, icshare, icapp, icrate, iclike, icupdate;
    TextView appinfo;
    Toolbar tb;
    LinearLayout email, call, web, share, moreapps, rate, likefb, update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer);

        tb = (Toolbar) findViewById(R.id.dev_toolbar);
        setSupportActionBar(tb);
        icmail = (TextView) findViewById(R.id.dev_ic_mail);
        icphone = (TextView) findViewById(R.id.dev_ic_phone);
        icweb = (TextView) findViewById(R.id.dev_ic_web);
        icshare = (TextView) findViewById(R.id.dev_ic_share);
        icapp = (TextView) findViewById(R.id.dev_ic_app);
        icrate = (TextView) findViewById(R.id.dev_ic_rate);
        iclike = (TextView) findViewById(R.id.dev_ic_like);
        icupdate = (TextView) findViewById(R.id.dev_ic_update);
        appinfo = (TextView) findViewById(R.id.dev_tv_appinfo);

        email = (LinearLayout) findViewById(R.id.dev_email);
        call = (LinearLayout) findViewById(R.id.dev_call);
        web = (LinearLayout) findViewById(R.id.dev_web);
        share = (LinearLayout) findViewById(R.id.dev_share);
        moreapps = (LinearLayout) findViewById(R.id.dev_more_apps);
        rate = (LinearLayout) findViewById(R.id.dev_rate);
        likefb = (LinearLayout) findViewById(R.id.dev_like_fb);
        update = (LinearLayout) findViewById(R.id.dev_update);


        Typeface materialface = Typeface.createFromAsset(getAssets(), "MaterialFont.ttf");
        icmail.setTypeface(materialface);
        icphone.setTypeface(materialface);
        icweb.setTypeface(materialface);
        icshare.setTypeface(materialface);
        icapp.setTypeface(materialface);
        icrate.setTypeface(materialface);
        iclike.setTypeface(materialface);
        icupdate.setTypeface(materialface);


        appinfo.setText(getResources().getString(R.string.app_name) + " (v" + BuildConfig.VERSION_NAME + ")");

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emailintent = new Intent("android.intent.action.SENDTO", Uri.fromParts("mailto", Constant.ASWDCEmailAddress, null));
                emailintent.putExtra("android.intent.extra.SUBJECT", "Contact from " + getString(R.string.app_name));
                startActivity(Intent.createChooser(emailintent, "Send Email to ASWDC"));
            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+"+ Constant.AdminMobileNo));
                startActivity(intent);
            }
        });

        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent webintent = new Intent("android.intent.action.VIEW", Uri.parse("http://www.darshan.ac.in"));
                startActivity(webintent);
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent();
                share.setAction("android.intent.action.SEND");
                share.setType("text/plain");
                share.putExtra("android.intent.extra.TEXT", "Hey, I downloaded an amazing app!" +
                        "\nGujarat IT, It is best for finding IT companies in Gujarat" +
                        "\nDownload it from Google Play Store : "+Constant.AppPlayStoreLink);
                startActivity(share);
            }
        });

        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent rateintent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.gujaratit"));
                startActivity(rateintent);
            }
        });

        moreapps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent moreappsintent = new Intent("android.intent.action.VIEW", Uri.parse("market://search?q=pub:Darshan+Institute+of+Engineering+%26+Technology"));
                startActivity(moreappsintent);
            }
        });

        likefb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fbintent = new Intent("android.intent.action.VIEW", Uri.parse("https://www.facebook.com/DarshanInstitute.Official"));
                startActivity(fbintent);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent updateintent = new Intent("android.intent.action.VIEW", Uri.parse("http://www.darshan.ac.in"));
                startActivity(updateintent);
            }
        });


    }
}
