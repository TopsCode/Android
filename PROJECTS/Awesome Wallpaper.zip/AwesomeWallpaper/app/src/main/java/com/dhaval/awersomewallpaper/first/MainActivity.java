 package com.dhaval.awersomewallpaper.first;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.MediaRouteButton;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.style.BackgroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RecyclerView recyclerView, recyclerView1;
    // TextView btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    WallpaperAdapter wallpaperAdapter;


    List<UnifiedNativeAd> nativeAds= new ArrayList<>();
    AdView adView;
    AdLoader adLoader;
    private boolean stateChanged;
    Button btn, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9,btn12,btn10,btn13,btn14;

    List<WallpaperModel> wallpaperModelList;
    int pageNumber = 1;
    String Url1 = "https://api.pexels.com/v1/curated/?page=" + pageNumber + "&per_page=80";
    Boolean isScrolling = false;
    int currentItems, totalItems, scrollOutItems;
    String url = "https://api.pexels.com/v1/curated/?page=" + pageNumber + "&per_page=80";
    private Object changecolor;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        btn1 = findViewById(R.id.btn1);
        btn3 = findViewById(R.id.btn2);
        btn10=findViewById(R.id.btn11);
        btn4 = findViewById(R.id.btn3);
        btn5 = findViewById(R.id.btn4);
        btn6 = findViewById(R.id.btn5);
        btn7 = findViewById(R.id.btn6);
        btn8 = findViewById(R.id.btn7);
        btn9 = findViewById(R.id.btn8);
        btn2 = findViewById(R.id.btn9);
        btn12=findViewById(R.id.btn12);
        btn13=findViewById(R.id.btn13);
        btn14=findViewById(R.id.btn14);


        btn.setBackgroundTintList(null);
        btn1.setBackgroundTintList(null);
        btn2.setBackgroundTintList(null);
        btn3.setBackgroundTintList(null);
        btn4.setBackgroundTintList(null);
        btn5.setBackgroundTintList(null);
        btn6.setBackgroundTintList(null);
        btn7.setBackgroundTintList(null);
        btn8.setBackgroundTintList(null);
        btn9.setBackgroundTintList(null);
        btn10.setBackgroundTintList(null);
        btn12.setBackgroundTintList(null);
        btn13.setBackgroundTintList(null);
        btn14.setBackgroundTintList(null);

        btn.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn10.setOnClickListener(this);
        btn12.setOnClickListener(this);
        btn13.setOnClickListener(this);
        btn14.setOnClickListener(this);

        MobileAds.initialize(this,getResources().getString(R.string.Native));
        adView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder()
                .build();
        adView.loadAd(adRequest);




       recyclerView = findViewById(R.id.recyclerView);
       recyclerView.setHasFixedSize(true);
        wallpaperModelList = new ArrayList<>();
        wallpaperAdapter = new WallpaperAdapter(this, wallpaperModelList);

        recyclerView.setAdapter(wallpaperAdapter);

        final GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2 );
        recyclerView.setLayoutManager(gridLayoutManager);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    isScrolling = true;
                }

            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                currentItems = gridLayoutManager.getChildCount();
                totalItems = gridLayoutManager.getItemCount();
                scrollOutItems = gridLayoutManager.findFirstVisibleItemPosition();

                if (isScrolling && (currentItems + scrollOutItems == totalItems)) {
                    isScrolling = false;
                    fetchWallpaper();
                }


            }
        });


        fetchWallpaper();
        loadNativeAds;

    }


    public void loadNativeAds(){
        AdLoader.Builder builder= new AdLoader.Builder(this,getResources().getString(R.string.Native));
        adLoader=builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            @Override
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {

                nativeAds.add(unifiedNativeAd);
                if (!adLoader.isLoading()){
                    insertAdsinMenuItem;
            }
        }).withAdListener(new AdListener(){
            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                    if (!adLoader.isLoading()) {
                        insertAdsinMenuItem;
                    }
            }
        }).build();
        }
        adLoader.loadAd(new AdRequest.Builder().build(),Number_of_Ads);

    };
    private  void insertAdsinMenuItem()
    {

    }

    public void fetchWallpaper() {

        StringRequest request = new StringRequest(Request.Method.GET, Url1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            JSONArray jsonArray = jsonObject.getJSONArray("photos");

                            int length = jsonArray.length();

                            for (int i = 0; i < length; i++) {

                                JSONObject object = jsonArray.getJSONObject(i);

                                int id = object.getInt("id");

                                JSONObject objectImages = object.getJSONObject("src");

                                String orignalUrl = objectImages.getString("original");
                                String mediumUrl = objectImages.getString("medium");

                                WallpaperModel wallpaperModel = new WallpaperModel(id, orignalUrl, mediumUrl);
                                wallpaperModelList.add(wallpaperModel);


                            }

                            wallpaperAdapter.notifyDataSetChanged();
                            pageNumber++;

                        } catch (JSONException e) {

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Authorization", "563492ad6f917000010000011d2e266949824efca8e7780b2b99e886");

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(request);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.nav_search) {

            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            final EditText editText = new EditText(this);
            editText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

            alert.setMessage("Enter Category e.g. Nature");
            alert.setTitle("Search Wallpaper");

            alert.setView(editText);

            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    String query = editText.getText().toString().toLowerCase();

                    Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=" + query;
                    wallpaperModelList.clear();
                    fetchWallpaper();

                }
            });

            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });

            alert.show();


        }

        return super.onOptionsItemSelected(item);
    }


    public void onClick(View v) {


        if (v == btn) {

            Url1 = "https://api.pexels.com/v1/curated/?page=" + pageNumber + "&per_page=80";
            wallpaperModelList.clear();
            fetchWallpaper();


        }
        if (v == btn1) {

            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=nature";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn2) {
            // btn2.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=animal";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn3) {
            // btn3.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=bird";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn4) {
            // btn4.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=wild";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn5) {
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=cool";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn6) {
            //  btn6.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=girl";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn7) {
            // btn7.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=boy";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn8) {
            //   btn8.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=watch";
            wallpaperModelList.clear();
            fetchWallpaper();

        }
        if (v == btn9) {
            //  btn9.setBackgroundColor(Color.GRAY);
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=car";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn10)
        {
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=romance";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn12)
        {
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=juice";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn13)
        {
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=cake";
            wallpaperModelList.clear();
            fetchWallpaper();
        }
        if (v == btn14)
        {
            Url1 = "https://api.pexels.com/v1/search/?page=" + pageNumber + "&per_page=80&query=motorbike";
            wallpaperModelList.clear();
            fetchWallpaper();
        }

    }

}
